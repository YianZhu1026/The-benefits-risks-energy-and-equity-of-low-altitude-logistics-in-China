# -*- coding: utf-8 -*-
"""
ArcPy Script: Calculate Hourly Network Risk Exposure

This script calculates the total risk exposure for a network of lines
as it passes through a risk grid. The risk grid has 24-hour values
(e.g., 'value_00', 'value_01', ...).

The workflow is as follows:
1. Intersect the network lines with the risk grid polygons.
2. Calculate the length (in meters) of each resulting line segment.
3. Spatially join the intersected segments back to the original grid,
   summing the total length of network lines within each grid cell.
4. Loop 24 times (once per hour):
   a. Calculate hourly risk for each cell (Risk = value_i * Total_Length).
   b. Sum the total risk across all cells and apply a normalization factor.
"""

import arcpy
import os
import sys
from datetime import datetime

# -----------------
# CONFIGURATION
# -----------------
# --- City and Index ---
CITY_NAME = "Harbin"
RISK_INDEX = 8.514936257

# --- Paths ---
WORKSPACE = f"F:/ResearchData/05-Paper/05_UAV4NC_2025/Code/Data/City/{CITY_NAME}/"
NETWORK_SHP = "Network/Network.shp"
MESH_SHP = f"mesh/mesh_{CITY_NAME.lower()}.shp"

# --- Output File Names ---
# Intermediate file for intersected line segments
INTERSECT_OUT_SHP = "Network/intersect_for_risk.shp"
# Final output grid containing summed lengths and calculated risks
FINAL_RESULT_GRID_SHP = "risk_summary_grid.shp"

# --- Field Names ---
LENGTH_FIELD = "Length"  # Name for the length field
POP_FIELD_PREFIX = "value_"
RISK_FIELD_PREFIX = "risk_"

# --- Normalization Factor ---
# This constant (500*500*10000) was in the original script
NORMALIZATION_FACTOR = (500 * 500 * 10000)


# -----------------


def main():
    """
    Main function to execute the geoprocessing workflow.
    """
    start_time = datetime.now()
    arcpy.AddMessage(f"Starting Network Risk Analysis for {CITY_NAME}...")

    try:
        # --- Environment Setup ---
        arcpy.env.workspace = WORKSPACE
        arcpy.env.overwriteOutput = True

        # --- Define Full Paths ---
        network_path = os.path.join(WORKSPACE, NETWORK_SHP)
        mesh_path = os.path.join(WORKSPACE, MESH_SHP)
        intersect_path = os.path.join(WORKSPACE, INTERSECT_OUT_SHP)
        result_path = os.path.join(WORKSPACE, FINAL_RESULT_GRID_SHP)

        # --- 1. Intersect Network and Mesh ---
        arcpy.AddMessage("Step 1/5: Intersecting network and mesh...")
        arcpy.analysis.Intersect(
            in_features=[network_path, mesh_path],
            out_feature_class=intersect_path,
            join_attributes="ALL",
            output_type="LINE"
        )
        arcpy.AddMessage(f"  -> Intersect file created: {intersect_path}")

        # --- 2. Add and Calculate Length Field ---
        arcpy.AddMessage(f"Step 2/5: Calculating length for intersected segments...")
        arcpy.management.AddField(
            in_table=intersect_path,
            field_name=LENGTH_FIELD,
            field_type="DOUBLE"
        )

        # Calculate length in meters
        arcpy.management.CalculateField(
            in_table=intersect_path,
            field=LENGTH_FIELD,
            expression="!shape.length@meters!",
            expression_type="PYTHON3"
        )

        # --- 3. Define Field Mappings for Spatial Join ---
        arcpy.AddMessage("Step 3/5: Defining field mappings...")
        field_mappings = arcpy.FieldMappings()

        # Add all fields from the Target (Mesh)
        # Add 'Join_Count' and 'TARGET_FID' (as in original script)
        field_map_jc = arcpy.FieldMap()
        field_map_jc.addInputField(mesh_path, "Join_Count")
        field_mappings.addFieldMap(field_map_jc)

        field_map_fid = arcpy.FieldMap()
        field_map_fid.addInputField(mesh_path, "TARGET_FID")
        field_mappings.addFieldMap(field_map_fid)

        # Add all hourly value fields (value_00 to value_23)
        for i in range(24):
            hour_str = str(i).zfill(2)
            pop_field = f"{POP_FIELD_PREFIX}{hour_str}"
            field_map = arcpy.FieldMap()
            field_map.addInputField(mesh_path, pop_field)
            field_mappings.addFieldMap(field_map)

        # Add the 'Length' field from the Join (Intersect)
        # and set its merge rule to SUM
        field_map_len = arcpy.FieldMap()
        field_map_len.addInputField(intersect_path, LENGTH_FIELD)
        field_map_len.mergeRule = "SUM"
        field_mappings.addFieldMap(field_map_len)

        # --- 4. Run Spatial Join ---
        arcpy.AddMessage("Step 4/5: Running Spatial Join to sum lengths per grid cell...")
        arcpy.analysis.SpatialJoin(
            target_features=mesh_path,
            join_features=intersect_path,
            out_feature_class=result_path,
            join_operation="JOIN_ONE_TO_ONE",
            join_type="KEEP_ALL",
            field_mapping=field_mappings,
            match_option="CONTAINS"
        )
        arcpy.AddMessage(f"  -> Result grid created: {result_path}")

        # --- 5. Calculate Hourly Risk ---
        arcpy.AddMessage("Step 5/5: Calculating total risk for each hour...")

        for i in range(24):
            hour_str = str(i).zfill(2)

            # Define field names for this hour
            risk_field = f"{RISK_FIELD_PREFIX}{hour_str}"
            pop_field = f"{POP_FIELD_PREFIX}{hour_str}"

            # Add the new 'risk_##' field
            arcpy.management.AddField(result_path, risk_field, "DOUBLE")

            # Calculate risk = value_## * SUM_Length
            expression = f"!{pop_field}! * !{LENGTH_FIELD}!"
            arcpy.management.CalculateField(
                in_table=result_path,
                field=risk_field,
                expression=expression,
                expression_type="PYTHON3"
            )

            # Sum the total risk for this hour from all grid cells
            total_risk_for_hour = 0
            with arcpy.da.SearchCursor(result_path, [risk_field]) as cursor:
                for row in cursor:
                    if row[0] is not None:
                        total_risk_for_hour += row[0]

            # Apply the final normalization and index
            normalized_risk = (total_risk_for_hour / NORMALIZATION_FACTOR) * RISK_INDEX

            # Output the result for this hour
            arcpy.AddMessage(f"  -> Hour {hour_str} | Total Normalized Risk: {normalized_risk:.6f}")

        duration = (datetime.now() - start_time).total_seconds()
        arcpy.AddMessage("\n" + "=" * 30)
        arcpy.AddMessage(f"Analysis complete!")
        arcpy.AddMessage(f"Total time: {duration:.2f} seconds")
        arcpy.AddMessage(f"Final output file: {result_path}")
        arcpy.AddMessage("=" * 30)

    except arcpy.ExecuteError:
        # Catch geoprocessing errors
        arcpy.AddError(arcpy.GetMessages(2))
    except Exception as e:
        # Catch other Python errors
        arcpy.AddError(f"An unexpected error occurred: {e}")
        import traceback
        arcpy.AddError(traceback.format_exc())


if __name__ == "__main__":
    main()