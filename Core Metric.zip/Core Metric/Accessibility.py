# -*- coding: utf-8 -*-
"""
Weighted Gini Coefficient Calculator for Accessibility

This script measures the "fairness" or "equity" of logistics station accessibility
across a population grid. It calculates accessibility as:
    Ratio = Population / Distance_to_nearest_station

It then computes a population-weighted Gini coefficient based on this ratio.
A Gini coefficient of 0 represents perfect equality (everyone has the
same accessibility ratio), while a value closer to 1 represents
perfect inequality.

Key Steps:
1. Load logistics station (DN) locations from CSV.
2. Load population grid from Shapefile.
3. Automatically project both datasets to a suitable local UTM CRS for
   accurate distance measurement (in meters).
4. For each grid cell, find the distance to the *nearest* logistics station.
5. Handle potential divide-by-zero errors (distance = 0).
6. Calculate the accessibility ratio (Population / Distance).
7. Calculate the population-weighted Gini coefficient of this ratio.
"""

import pandas as pd
import geopandas as gpd
import numpy as np
from scipy.spatial import cKDTree

# --- CONFIGURATION ---
# Edit these variables to match your data
# ---------------------
CITY_NAME = "Chongqing"
BASE_CRS = "EPSG:4326"  # CRS of the input CSV (WGS84)

# Input file paths
DN_CSV_PATH = f'Data/City/{CITY_NAME}/DN_coordinates.csv'
GRID_SHP_PATH = f'Data/City/{CITY_NAME}/mesh/mesh_{CITY_NAME.lower()}.shp'

# Input column names
DN_X_COL = 'log'  # Longitude column in CSV
DN_Y_COL = 'lat'  # Latitude column in CSV
POP_COL = 'Value'  # Population field name in Shapefile


# ---------------------

def calculate_weighted_gini(values, weights):
    """
    Calculates the population-weighted Gini coefficient.

    This is a fast O(n log n) implementation based on sorting.
    It is mathematically equivalent to the O(n^2) formula:
      G = Σ Σ [w_i * w_j * |y_i - y_j|] / [2 * (Σ w_k) * (Σ w_k * y_k)]

    Args:
        values (np.array): The array of values (e.g., accessibility ratio).
        weights (np.array): The array of weights (e.g., population).

    Returns:
        float: The weighted Gini coefficient (between 0 and 1).
    """
    print("Calculating weighted Gini coefficient...")

    # Combine values and weights and remove any NaNs
    stack = np.stack([values, weights], axis=1)
    stack = stack[~np.isnan(stack).any(axis=1)]

    # Sort by value (y_i)
    sorted_indices = np.argsort(stack[:, 0])
    stack_sorted = stack[sorted_indices]

    values_sorted = stack_sorted[:, 0]
    weights_sorted = stack_sorted[:, 1]

    # Get cumulative sums
    cum_weights = np.cumsum(weights_sorted)
    cum_weighted_values = np.cumsum(weights_sorted * values_sorted)

    # Get totals
    total_weight = cum_weights[-1]
    total_weighted_value = cum_weighted_values[-1]

    # Gini formula based on sorted cumulative sums
    # This is the O(n log n) implementation
    gini = (np.sum(weights_sorted * cum_weighted_values) -
            (total_weight * total_weighted_value))
    gini = gini / (total_weight * total_weighted_value)
    gini = (2 * gini) - 1

    return gini


def main():
    """
    Main execution function of the script.
    """

    # --- 1. Load Logistics Stations (DNs) ---
    print(f"Loading logistics stations from: {DN_CSV_PATH}")
    logistics_df = pd.read_csv(DN_CSV_PATH)

    # Convert CSV to GeoDataFrame using the efficient points_from_xy
    logistics_gdf = gpd.GeoDataFrame(
        logistics_df,
        geometry=gpd.points_from_xy(logistics_df[DN_X_COL], logistics_df[DN_Y_COL]),
        crs=BASE_CRS  # Assign the input CRS (WGS84)
    )
    print(f"Loaded {len(logistics_gdf)} logistics stations.")

    # --- 2. Load Population Grid ---
    print(f"Loading population grid from: {GRID_SHP_PATH}")
    try:
        population_grid = gpd.read_file(GRID_SHP_PATH)
    except Exception as e:
        print(f"Error loading Shapefile: {e}")
        return

    # Check if population column exists
    if POP_COL not in population_grid.columns:
        print(f"Error: Population column '{POP_COL}' not found in Shapefile.")
        print(f"Available columns are: {population_grid.columns.to_list()}")
        return

    # Filter grid: Keep only necessary columns and valid data
    # (Valid geometry and population > 0)
    population_grid = population_grid[['geometry', POP_COL]].copy()
    population_grid = population_grid[
        (~population_grid.geometry.is_empty) &
        (population_grid.geometry.is_valid) &
        (population_grid[POP_COL] > 0)
        ]
    print(f"Loaded {len(population_grid)} valid population grid cells.")

    # --- 3. Project to Local UTM ---
    # CRITICAL: Estimate a local projected CRS (like UTM) for accurate
    # distance calculation in meters, instead of using a wrong one.
    print(f"Original grid CRS: {population_grid.crs}")
    projected_crs = population_grid.estimate_utm_crs()
    print(f"Projecting to estimated local CRS: {projected_crs} (for meter-based calculations)")

    population_grid = population_grid.to_crs(projected_crs)
    logistics_gdf = logistics_gdf.to_crs(projected_crs)

    # --- 4. Prepare Coordinate Arrays ---
    print("Extracting coordinates for distance calculation...")

    # Extract logistics (DN) coordinates
    logistics_coords_proj = np.vstack(
        (logistics_gdf.geometry.x, logistics_gdf.geometry.y)
    ).T

    # Extract grid cell centroids
    grid_centroids = population_grid.geometry.representative_point()
    grid_coords_proj = np.vstack((grid_centroids.x, grid_centroids.y)).T

    # Extract population data
    population_data = population_grid[POP_COL].values

    # --- 5. Calculate Nearest Distance ---
    print("Building KDTree for nearest neighbor search...")
    # Use cKDTree for efficient spatial queries
    tree = cKDTree(logistics_coords_proj)

    print("Querying nearest distance for each grid cell...")
    distances, _ = tree.query(grid_coords_proj)  # Distances are in meters

    # CRITICAL FIX: Handle divide-by-zero error
    # If a distance is 0 (station is on the centroid), set it to 1.0 meter
    # to prevent 'inf' in the ratio calculation.
    distances[distances == 0] = 1.0

    # --- 6. Calculate Accessibility Ratio ---
    print("Calculating accessibility ratio (Population / Distance)...")
    accessibility_ratio = population_data / distances

    # --- 7. Calculate Weighted Gini Coefficient ---
    gini = calculate_weighted_gini(accessibility_ratio, population_data)

    print("\n" + "=" * 30)
    print(f"Analysis Complete for: {CITY_NAME}")
    print(f"  Weighted Gini Coefficient: {gini:.6f}")
    print("=" * 33)


if __name__ == "__main__":
    main()