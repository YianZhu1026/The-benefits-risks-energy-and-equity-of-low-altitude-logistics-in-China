#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
REQP (Risk-Energy-Equity-Potential) Multi-Objective Analysis Script

Performs analysis on 4-objective optimization results (REQP).
- Finds the empirical Pareto frontier.
- Calculates the distance to the frontier for all data points.
- Implements epsilon-constraint trade-off analysis.
- "Slims" the Pareto frontier using one of three methods (epsilon-grid,
  crowding distance, or farthest point sampling) for clearer visualization.
- Generates 2D and 3D plots of the results.

Note: This script assumes 'Equity' is a cost to be minimized
(e.g., Gini coefficient, where lower is better).

Dependencies: pandas, numpy, matplotlib
  pip install pandas numpy matplotlib

Example Usage:
python reqp_frontier_analysis.py --csv REQP_cities.csv \
  --risk_col Risk --energy_col Energy --equity_col Equity --potential_col Potential \
  --front_method epsilon --front_eps 0.05 --front_limit 80 \
  --outdir ./reqp_output --epsilon_grid 9
"""
import os
import argparse
import sys
from typing import Tuple, List
import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")  # Use non-interactive backend for saving files
import matplotlib.pyplot as plt


# ---------------- Utility Functions ----------------

def minmax(a: pd.Series) -> np.ndarray:
    """Normalizes a pandas Series to the [0, 1] range."""
    lo, hi = float(a.min()), float(a.max())
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
        # Handle constant or invalid series
        x = np.zeros(len(a), dtype=float)
    else:
        x = (a.values.astype(float) - lo) / (hi - lo)
    x[~np.isfinite(x)] = 0.0  # Clean up NaNs
    return x


def non_dominated_mask(vals: np.ndarray) -> np.ndarray:
    """
    Finds the non-dominated (Pareto) frontier using O(N^2) comparison.

    Args:
        vals: (n, d) numpy array where all 'd' objectives are to be *minimized*.

    Returns:
        A boolean mask (shape n,) where True indicates a point is on the Pareto frontier.
    """
    n = vals.shape[0]
    is_dominated = np.zeros(n, dtype=bool)
    for i in range(n):
        if is_dominated[i]:
            continue
        v_i = vals[i]
        for j in range(n):
            if i == j:
                continue
            v_j = vals[j]
            # Check if j dominates i
            if np.all(v_j <= v_i) and np.any(v_j < v_i):
                is_dominated[i] = True
                break
    return ~is_dominated


def ensure_outdir(d: str) -> str:
    """Ensures the output directory exists."""
    if not d:
        d = "."
    os.makedirs(d, exist_ok=True)
    return d


def parse_eps_list(arg: str, dims: int) -> List[float]:
    """
    Parses the --front_eps argument string into a list of floats.
    Allows a single value (e.g., "0.05") or a comma-separated list (e.g., "0.1,0.05,0.1,0.02").
    """
    default = [0.05] * dims
    if arg is None:
        return default
    try:
        parts = [float(x.strip()) for x in str(arg).split(",")]
    except Exception:
        return default

    if len(parts) == 1:
        # Use the single value for all dimensions
        v = max(1e-6, float(parts[0]))
        return [v] * dims

    # Use the comma-separated list, repeating the last value if needed
    out = []
    last = parts[0]
    for i in range(dims):
        if i < len(parts):
            last = parts[i]
        out.append(max(1e-6, float(last)))
    return out


# ---------- Frontier "Slimming" (Reduction) Methods ----------

def reduce_front_epsilon(vals: np.ndarray, limit: int, eps: List[float]) -> np.ndarray:
    """
    Reduces the frontier by binning points into an epsilon-grid.
    Keeps only one representative (the one with the best sum) from each occupied bin.
    If the result is still > 'limit', it falls back to crowding distance.
    """
    # Bin each point into a grid cell
    bins = np.floor(vals / np.asarray(eps)).astype(int)
    keys = [tuple(row) for row in bins]

    chosen = {}
    sums = np.sum(vals, axis=1)  # Use sum as the tie-breaker

    for idx, key in enumerate(keys):
        # If bin is empty or this point is better (lower sum) than the current occupant
        if key not in chosen or sums[idx] < sums[chosen[key]]:
            chosen[key] = idx

    idxs = np.array(list(chosen.values()), dtype=int)

    # If the epsilon grid is still too coarse, apply crowding distance
    if limit is not None and limit > 0 and len(idxs) > limit:
        return reduce_front_crowding(vals[idxs], limit, base_indices=idxs)

    return np.sort(idxs)


def _crowding_distance(vals: np.ndarray) -> np.ndarray:
    """Calculates the crowding distance for each point (NSGA-II method)."""
    n, d = vals.shape
    cd = np.zeros(n, dtype=float)
    if n == 0:
        return cd

    for k in range(d):
        # Sort by this objective
        order = np.argsort(vals[:, k], kind="mergesort")
        vk = vals[order, k]
        span = float(vk[-1] - vk[0])

        if span <= 1e-12:
            continue  # Skip if all values in this dimension are the same

        # Assign infinite distance to boundaries
        cd[order[0]] = np.inf
        cd[order[-1]] = np.inf

        # Calculate distance for intermediate points
        for i in range(1, n - 1):
            cd[order[i]] += (vk[i + 1] - vk[i - 1]) / span

    return cd


def reduce_front_crowding(vals: np.ndarray, limit: int, base_indices: np.ndarray = None) -> np.ndarray:
    """Reduces the frontier by keeping the 'limit' points with the largest crowding distance."""
    n = len(vals)
    if limit is None or limit <= 0 or limit >= n:
        idx = np.arange(n, dtype=int)
        return base_indices[idx] if base_indices is not None else idx

    cd = _crowding_distance(vals)
    order = np.argsort(-cd)  # Sort descending by crowding distance

    keep_local = order[:limit]
    keep_local.sort()  # Sort back to original index order

    return (base_indices[keep_local] if base_indices is not None else keep_local)


def reduce_front_fps(vals: np.ndarray, limit: int) -> np.ndarray:
    """
    Reduces the frontier using Farthest Point Sampling (FPS)
    to get a well-spread set of points.
    """
    n = len(vals)
    idx_all = np.arange(n, dtype=int)
    if limit is None or limit <= 0 or limit >= n:
        return idx_all

    # Start with the "best" point (min sum)
    seed = int(np.argmin(np.sum(vals, axis=1)))
    selected = [seed]

    # Initialize min distances from all points to the selected set
    dmin = np.full(n, np.inf, dtype=float)
    dmin[:] = np.linalg_norm(vals - vals[seed], axis=1)
    dmin[seed] = -np.inf  # Ensure seed is not picked again

    while len(selected) < limit:
        # Pick the point farthest from the *current set*
        nxt = int(np.argmax(dmin))
        selected.append(nxt)

        # Update min distances
        dmin = np.minimum(dmin, np.linalg_norm(vals - vals[nxt], axis=1))
        dmin[nxt] = -np.inf  # Ensure this point is not picked again

    return np.sort(np.array(selected, dtype=int))


def choose_reduced_indices(front_vals: np.ndarray,
                           method: str,
                           limit: int,
                           eps: List[float]) -> np.ndarray:
    """Wrapper function to select a frontier reduction (slimming) method."""
    method = (method or "epsilon").lower()
    if method == "epsilon":
        return reduce_front_epsilon(front_vals, limit, eps)
    elif method == "crowding":
        return reduce_front_crowding(front_vals, limit)
    elif method == "fps":
        return reduce_front_fps(front_vals, limit)
    else:  # "none" or unknown
        return np.arange(len(front_vals), dtype=int)


# ---------------- Main Workflow ----------------
def run_req_frontier(df: pd.DataFrame,
                     risk_col: str, energy_col: str, equity_col: str, potential_col: str,
                     id_col: str = "City",
                     epsilon_grid: int = 9,
                     outdir: str = ".",
                     front_method: str = "epsilon",
                     front_limit: int = 100,
                     front_eps_arg: str = None) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Main function to run the full REQP analysis.
    """
    outdir = ensure_outdir(outdir)

    # --- 1) Validate Columns ---
    need_cols = [risk_col, energy_col, equity_col, potential_col]
    miss = [c for c in need_cols if c not in df.columns]
    if miss:
        raise ValueError(f"Missing required columns: {miss}")
    if id_col not in df.columns:
        df = df.copy()
        df[id_col] = [f"item_{i}" for i in range(len(df))]  # Add a default ID

    # --- 2) Normalize Objectives (all to be *minimized*) ---
    Rn = minmax(df[risk_col])  # Risk (min is better)
    En = minmax(df[energy_col])  # Energy (min is better)
    Fcost = minmax(df[equity_col])  # Equity as cost (min is better, e.g., Gini)
    Pn = minmax(df[potential_col])  # Potential (max is better)
    Pcost = 1.0 - Pn  # Convert to P_cost (min is better)

    work = df[[id_col, risk_col, energy_col, equity_col, potential_col]].copy()
    work["R_norm"] = Rn
    work["E_norm"] = En
    work["Fairness_norm"] = Fcost
    work["P_norm"] = Pn
    work["P_cost"] = Pcost

    # This is the 4D array for minimization
    vals = work[["R_norm", "E_norm", "Fairness_norm", "P_cost"]].to_numpy(float)

    # --- 3) Find the Full Pareto Frontier ---
    mask_front = non_dominated_mask(vals)
    work["Pareto"] = mask_front
    front_full = work.loc[mask_front].reset_index(drop=True)
    front_vals = front_full[["R_norm", "E_norm", "Fairness_norm", "P_cost"]].to_numpy(float)

    # --- 4) "Slim" (Reduce) the Frontier for Visualization ---
    eps_list = parse_eps_list(front_eps_arg, dims=4)
    keep_idx = choose_reduced_indices(front_vals, front_method, front_limit, eps_list)
    front_reduced = front_full.iloc[keep_idx].reset_index(drop=True)

    # --- 5) Calculate Distance to Frontier for ALL points ---
    dist2front = np.zeros(len(work), dtype=float)
    nearest = np.empty(len(work), dtype=object)
    imp = np.zeros((len(work), 4), dtype=float)  # Improvement potential

    for i, xi in enumerate(vals):
        # Find nearest point *on the full frontier*
        jbest = int(np.argmin(np.linalg.norm(front_vals - xi, axis=1)))
        dmin = float(np.linalg.norm(xi - front_vals[jbest]))
        dist2front[i] = dmin
        nearest[i] = front_full.loc[jbest, id_col]
        # Improvement = how much better the frontier point is
        delta = xi - front_vals[jbest]
        imp[i, :] = np.maximum(0.0, delta)

    work["dist2front"] = dist2front
    work["nearest_front"] = nearest
    work["improve_R_norm"] = imp[:, 0]
    work["improve_E_norm"] = imp[:, 1]
    work["improve_Fairness_norm"] = imp[:, 2]
    work["improve_Pcost_norm"] = imp[:, 3]

    # --- 6) Epsilon-Constraint Trade-off Analysis ---
    #    For a given capability (R_cap, E_cap), what is the
    #    best possible Fairness and Potential we can achieve?
    qs = np.linspace(0.1, 0.9, max(3, int(epsilon_grid)))
    R_caps = np.quantile(work["R_norm"], qs)
    E_caps = np.quantile(work["E_norm"], qs)

    records = []
    for rcap in R_caps:
        for ecap in E_caps:
            # Find all solutions that meet the (R, E) constraints
            feasible_set = work[(work["R_norm"] <= rcap) & (work["E_norm"] <= ecap)]
            if len(feasible_set) == 0:
                records.append((rcap, ecap, np.nan, None, np.nan, None))
            else:
                # Find best Equity (min) in the feasible set
                k_fair = feasible_set[equity_col].idxmin()
                # Find best Potential (max) in the feasible set
                k_pt = feasible_set[potential_col].idxmax()
                records.append((
                    rcap, ecap,
                    work.loc[k_fair, equity_col], work.loc[k_fair, id_col],
                    work.loc[k_pt, potential_col], work.loc[k_pt, id_col]
                ))

    tradeoff_df = pd.DataFrame(
        records,
        columns=["R_cap_norm", "E_cap_norm", "BestFairness", "BestCity_Fair", "BestPotential", "BestCity_Pt"]
    )

    # --- 7) Export CSVs ---
    work.to_csv(os.path.join(outdir, "reqp_all_points_results.csv"), index=False, encoding="utf-8-sig")
    front_full.to_csv(os.path.join(outdir, "reqp_pareto_frontier_full.csv"), index=False, encoding="utf-8-sig")
    front_reduced.to_csv(os.path.join(outdir, "reqp_pareto_frontier_reduced.csv"), index=False, encoding="utf-8-sig")
    tradeoff_df.to_csv(os.path.join(outdir, "reqp_tradeoff_epsilon.csv"), index=False, encoding="utf-8-sig")

    # --- 8) Generate Plots (use reduced frontier if available) ---
    fr = front_reduced if (len(front_reduced) > 0 and len(front_reduced) < len(front_full)) else front_full

    # 3D Plot: Risk, Energy, Fairness
    try:
        from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
        fig = plt.figure(figsize=(7, 5.6))
        ax = fig.add_subplot(111, projection='3d')
        ax.scatter(work["R_norm"], work["E_norm"], work["Fairness_norm"], alpha=0.85, label="All Solutions")
        ax.scatter(fr["R_norm"], fr["E_norm"], fr["Fairness_norm"], s=60,
                   label="Pareto Frontier (Reduced)" if fr is front_reduced else "Pareto Frontier")
        ax.set_xlabel("Normalized Risk (min is better)")
        ax.set_ylabel("Normalized Energy (min is better)")
        ax.set_zlabel("Normalized Equity (min is better)")
        ax.set_title("REQP 3D Frontier (Risk, Energy, Equity)")
        ax.legend();
        fig.tight_layout()
        fig.savefig(os.path.join(outdir, "reqp_3d_pareto_R_E_Fairness.png"), dpi=220, bbox_inches="tight")
        plt.close(fig)
    except Exception as e:
        print(f"Skipping 3D plots, possibly missing 'mpl_toolkits'. Error: {e}")

    # 3D Plot: Risk, Energy, P_cost
    try:
        fig = plt.figure(figsize=(7, 5.6))
        ax = fig.add_subplot(111, projection='3d')
        ax.scatter(work["R_norm"], work["E_norm"], work["P_cost"], alpha=0.85, label="All Solutions")
        ax.scatter(fr["R_norm"], fr["E_norm"], fr["P_cost"], s=60,
                   label="Pareto Frontier (Reduced)" if fr is front_reduced else "Pareto Frontier")
        ax.set_xlabel("Normalized Risk (min is better)")
        ax.set_ylabel("Normalized Energy (min is better)")
        ax.set_zlabel("Normalized Potential Cost (min is better)")
        ax.set_title("REQP 3D Frontier (Risk, Energy, Potential)")
        ax.legend();
        fig.tight_layout()
        fig.savefig(os.path.join(outdir, "reqp_3d_pareto_R_E_Pcost.png"), dpi=220, bbox_inches="tight")
        plt.close(fig)
    except Exception:
        pass  # Already warned

    # 2D Projections
    pairs = [
        ("R_norm", "E_norm", "reqp_2d_R_vs_E.png", "Normalized Risk (min)", "Normalized Energy (min)"),
        ("R_norm", "Fairness_norm", "reqp_2d_R_vs_Fairness.png", "Normalized Risk (min)", "Normalized Equity (min)"),
        ("E_norm", "Fairness_norm", "reqp_2d_E_vs_Fairness.png", "Normalized Energy (min)", "Normalized Equity (min)"),
        ("R_norm", "P_cost", "reqp_2d_R_vs_Pcost.png", "Normalized Risk (min)", "Normalized Potential Cost (min)"),
        ("E_norm", "P_cost", "reqp_2d_E_vs_Pcost.png", "Normalized Energy (min)", "Normalized Potential Cost (min)"),
    ]
    for xcol, ycol, fn, xlabel, ylabel in pairs:
        plt.figure(figsize=(6.6, 5.2))
        plt.scatter(work[xcol], work[ycol], alpha=0.85, label="All Solutions")
        plt.scatter(fr[xcol], fr[ycol], s=60,
                    label="Pareto Frontier (Reduced)" if fr is front_reduced else "Pareto Frontier")
        plt.xlabel(xlabel);
        plt.ylabel(ylabel);
        plt.title(f"{xlabel} vs {ylabel}")
        plt.legend();
        plt.grid(True, linestyle=':');
        plt.tight_layout()
        plt.savefig(os.path.join(outdir, fn), dpi=220, bbox_inches="tight")
        plt.close()

    # Epsilon-Constraint Heatmap: Best Fairness
    plt.figure(figsize=(6.6, 5.2))
    sc = plt.scatter(tradeoff_df["R_cap_norm"], tradeoff_df["E_cap_norm"], c=tradeoff_df["BestFairness"], s=70,
                     cmap="viridis_r")
    plt.colorbar(sc, label="Best Achievable Equity (Original Value; lower is better)")
    plt.xlabel("Risk Capability (Normalized)");
    plt.ylabel("Energy Capability (Normalized)")
    plt.title("ε-Constraint: Best Achievable Equity")
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, "reqp_tradeoff_eps_fairness.png"), dpi=220, bbox_inches="tight")
    plt.close()

    # Epsilon-Constraint Heatmap: Best Potential
    plt.figure(figsize=(6.6, 5.2))
    sc = plt.scatter(tradeoff_df["R_cap_norm"], tradeoff_df["E_cap_norm"], c=tradeoff_df["BestPotential"], s=70,
                     cmap="viridis")
    plt.colorbar(sc, label="Best Achievable Potential (Original Value)")
    plt.xlabel("Risk Capability (Normalized)");
    plt.ylabel("Energy Capability (Normalized)")
    plt.title("ε-Constraint: Best Achievable Potential")
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, "reqp_tradeoff_eps_potential.png"), dpi=220, bbox_inches="tight")
    plt.close()

    print(f"Analysis complete. Results saved to: {outdir}")
    return work, front_full, front_reduced, tradeoff_df


# ---------------- CLI (Command-Line Interface) ----------------
def main():
    """Main function to parse arguments and run the analysis."""
    ap = argparse.ArgumentParser(
        description="REQP (Risk-Energy-Equity-Potential) Frontier Analysis",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument("--csv", required=True,
                    help="Input CSV with columns for Risk, Energy, Equity, and Potential")
    ap.add_argument("--risk_col", default="Risk", help="Column name for Risk (to be minimized)")
    ap.add_argument("--energy_col", default="Energy", help="Column name for Energy (to be minimized)")
    ap.add_argument("--equity_col", default="Equity", help="Column name for Equity (to be minimized, e.g., Gini)")
    ap.add_argument("--potential_col", default="Potential", help="Column name for Potential (to be maximized)")
    ap.add_argument("--id_col", default="City", help="Column name for the solution/city identifier")
    ap.add_argument("--epsilon_grid", type=int, default=9,
                    help="Number of grid points (N) for the N_x_N epsilon-constraint analysis")
    ap.add_argument("--outdir", default="./reqp_output",
                    help="Output directory for CSVs and plots")

    # Frontier Slimming Arguments
    ap.add_argument("--front_method", choices=["epsilon", "crowding", "fps", "none"], default="epsilon",
                    help="Method to 'slim' the Pareto frontier for visualization")
    ap.add_argument("--front_limit", type=int, default=100,
                    help="Max number of points for the reduced frontier (<=0 for no limit)")
    ap.add_argument("--front_eps", type=str, default="0.05",
                    help="Epsilon step size (in normalized space) for 'epsilon' slimming method. "
                         "Can be one value (e.g., '0.05') or 4 comma-separated values "
                         "(e.g., '0.1,0.05,0.1,0.02') for R,E,Fairness,P_cost.")
    args = ap.parse_args()

    try:
        df = pd.read_csv(args.csv)
    except FileNotFoundError:
        print(f"Error: Input file not found at {args.csv}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error reading CSV: {e}", file=sys.stderr)
        sys.exit(1)

    run_req_frontier(df,
                     risk_col=args.risk_col,
                     energy_col=args.energy_col,
                     equity_col=args.equity_col,
                     potential_col=args.potential_col,
                     id_col=args.id_col,
                     epsilon_grid=args.epsilon_grid,
                     outdir=args.outdir,
                     front_method=args.front_method,
                     front_limit=args.front_limit,
                     front_eps_arg=args.front_eps)


if __name__ == "__main__":
    main()