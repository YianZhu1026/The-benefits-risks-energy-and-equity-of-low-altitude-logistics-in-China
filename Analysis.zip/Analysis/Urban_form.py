#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Performs scaling analysis based on log-identity decomposition
(e.g., ln(T) ~ β_T*ln(S) and ln(G) ~ β_G*ln(S), implying β_p = β_T - β_G).

Includes:
1. OLS regression with robust standard errors (HC3) for β_T and β_G.
2. Sliding-window OLS to estimate the trend of β_p as a function of S.
3. Confidence interval calculation for the sliding-window β_p,
   with optional covariance correction (Var(A-B) = Var(A) + Var(B) - 2*Cov(A,B)).
"""

import argparse
import os
from dataclasses import dataclass
from typing import List, Optional

import numpy as np
import pandas as pd
import statsmodels.api as sm
import matplotlib.pyplot as plt


@dataclass
class Config:
    """Script configuration dataclass."""
    csv_path: str
    t_col: str  # transport potential (T) column
    g_col: str  # ground baseline (G) column
    s_col: str  # scale S column
    controls: List[str]
    p_col: Optional[str] = None  # optional: observed share p in (0,1)
    robust: str = "HC3"
    make_plots: bool = True
    outdir: Optional[str] = None
    transparent: bool = False
    trend_window: int = 12
    trend_step: int = 1  # slide step for the window
    trend_x: str = "lnS"  # "lnS" or "S" on x-axis
    ci_alpha: float = 0.05  # 1 - confidence level for CI band (0.05 -> 95%)
    use_cov_correction: bool = True  # use Cov(β_T, β_G) ≈ ρ * se_T * se_G


def _safe_log(x: pd.Series, eps: float = 1e-10) -> pd.Series:
    """Calculates the natural log, clipping values at a small epsilon."""
    return np.log(np.clip(x.astype(float), eps, None))


def _safe_logit(p: pd.Series, eps: float = 1e-6) -> pd.Series:
    """Calculates the logit, clipping p to be within (eps, 1-eps)."""
    p = np.clip(p.astype(float), eps, 1 - eps)
    return np.log(p / (1 - p))


def fit_ols(y: pd.Series, X: pd.DataFrame, robust: str = "HC3"):
    """
    Fits an OLS model with robust standard errors.

    Args:
        y: Response variable
        X: Explanatory variables
        robust: Robust covariance type (e.g., "HC3")

    Returns:
        A fitted statsmodels OLSResults object.
    """
    X = sm.add_constant(X, has_constant='add')
    model = sm.OLS(y.astype(float), X.astype(float), missing='drop')
    res = model.fit(cov_type=robust)
    return res


def ensure_outdir(path: Optional[str], csv_path: str) -> str:
    """Ensures the output directory exists, or defaults to the CSV's directory."""
    if path:
        os.makedirs(path, exist_ok=True)
        return path
    d = os.path.dirname(os.path.abspath(csv_path))
    return d if d else "."


def _z_from_alpha(alpha: float) -> float:
    """
    Return z-quantile for two-sided (1-alpha) CI.
    e.g., alpha=0.05 -> 1.95996 (for 95% CI)
    """
    try:
        from scipy.stats import norm
        return float(norm.ppf(1.0 - alpha / 2.0))
    except ImportError:
        # Fallback lookup for common levels if scipy is not installed
        lut = {0.10: 1.644854, 0.05: 1.959964, 0.02: 2.326348, 0.01: 2.575829, 0.001: 3.290527}
        # Round to 3 decimals to match keys; default to 1.96
        return lut.get(round(alpha, 3), 1.959964)


def plot_lnS_vs_lnY(df: pd.DataFrame, lnS_col: str, lnY_col: str, res, y_label: str, outpath: str, transparent=False):
    """Plots the fitted regression line against the data."""
    plt.figure()
    plt.scatter(df[lnS_col], df[lnY_col], alpha=0.85, label="data")
    x_grid = np.linspace(df[lnS_col].min(), df[lnS_col].max(), 200)

    # Create prediction data, holding controls at their mean
    ctrl_cols = [c for c in res.model.exog_names if c not in ("const", "lnS")]
    pred_df = pd.DataFrame({"lnS": x_grid})
    for c in ctrl_cols:
        if c in df.columns:
            pred_df[c] = df[c].mean()
        else:
            pred_df[c] = 0.0

    pred_exog = sm.add_constant(pred_df, has_constant='add')
    y_hat = res.predict(pred_exog)

    plt.plot(x_grid, y_hat, linewidth=2, linestyle="--", label="fit")
    plt.xlabel("ln(S)")
    plt.ylabel(y_label)
    plt.title(f"{y_label} vs ln(S)")
    plt.legend()
    plt.tight_layout()
    plt.savefig(outpath, dpi=200, bbox_inches="tight", transparent=transparent)
    plt.close()


def plot_beta_bars(beta_T: float, beta_G: float, outpath: str, transparent=False):
    """Generates a bar plot of the three beta exponents."""
    beta_P = beta_T - beta_G
    labels = ["beta_T (lnT~lnS)", "beta_G (lnG~lnS)", "beta_p = T - G"]
    vals = [beta_T, beta_G, beta_P]

    plt.figure()
    plt.bar(labels, vals)
    plt.ylabel("Scaling exponent")
    plt.title("Scaling exponents: β_T, β_G, β_p")
    plt.axhline(0, color='black', linewidth=0.7)
    plt.tight_layout()
    plt.savefig(outpath, dpi=200, bbox_inches="tight", transparent=transparent)
    plt.close()


def compute_beta_p_trend(df: pd.DataFrame, s_col: str, t_col: str, g_col: str, controls: List[str],
                         window: int = 12, step: int = 1, robust: str = "HC3",
                         ci_alpha: float = 0.05, use_cov_correction: bool = True):
    """
    Sliding-window estimates of beta_p with an approximate (1-ci_alpha) CI.

    Calculates Var(β_p) = Var_T + Var_G - 2 * Cov_TG;
    where Cov_TG ≈ rho * se_T * se_G,
    and rho is corr(residual_T, residual_G) from the two models.
    """
    dd = df.sort_values(s_col).reset_index(drop=True).copy()
    dd["lnS"] = _safe_log(dd[s_col])
    dd["lnT"] = _safe_log(dd[t_col])
    dd["lnG"] = _safe_log(dd[g_col])

    centers_S, centers_lnS, betap = [], [], []
    se_betap, lo_betap, hi_betap, ns, rhos = [], [], [], [], []

    n = len(dd)
    if window < 5 or window > n:
        raise ValueError(f"Trend window must be in [5, {n}]")

    z = _z_from_alpha(ci_alpha)

    for start in range(0, n - window + 1, max(1, step)):
        sub = dd.iloc[start:start + window].copy()
        n_sub = len(sub)

        # Fit model for T
        XT = sub[["lnS"] + controls]
        resT = fit_ols(sub["lnT"], XT, robust=robust)
        bT = float(resT.params.get("lnS", np.nan))
        seT = float(resT.bse[resT.params.index.get_loc("lnS")]) if "lnS" in resT.params.index else np.nan

        # Fit model for G
        XG = sub[["lnS"] + controls]
        resG = fit_ols(sub["lnG"], XG, robust=robust)
        bG = float(resG.params.get("lnS", np.nan))
        seG = float(resG.bse[resG.params.index.get_loc("lnS")]) if "lnS" in resG.params.index else np.nan

        # Beta for p is the difference
        bp = bT - bG

        # Calculate standard error of the difference
        var_bp = seT ** 2 + seG ** 2 if (np.isfinite(seT) and np.isfinite(seG)) else np.nan
        rho = np.nan
        if use_cov_correction:
            try:
                # Use correlation of residuals as proxy for correlation of betas
                rT = np.asarray(resT.resid, dtype=float)
                rG = np.asarray(resG.resid, dtype=float)
                if rT.size == rG.size and rT.size >= 3:
                    rho = np.corrcoef(rT, rG)[0, 1]
                    if np.isfinite(rho):
                        # Full variance formula
                        var_bp = max(0.0, var_bp - 2.0 * rho * seT * seG)
            except Exception:
                pass  # Fallback to independence assumption

        # Confidence Interval
        se_bp = np.sqrt(var_bp) if np.isfinite(var_bp) else np.nan
        lo = bp - z * se_bp if np.isfinite(se_bp) else np.nan
        hi = bp + z * se_bp if np.isfinite(se_bp) else np.nan

        centers_S.append(sub[s_col].mean())
        centers_lnS.append(sub["lnS"].mean())
        betap.append(bp)
        se_betap.append(se_bp)
        lo_betap.append(lo)
        hi_betap.append(hi)
        ns.append(n_sub)
        rhos.append(rho)

    out = pd.DataFrame({
        "center_S": centers_S,
        "center_lnS": centers_lnS,
        "beta_p": betap,
        "se_beta_p": se_betap,
        "beta_p_lo": lo_betap,
        "beta_p_hi": hi_betap,
        "n_window": ns,
        "rho_resid_TG": rhos
    })
    return out


def plot_beta_p_trend(trend_df: pd.DataFrame, which_x: str, outpath: str, transparent=False):
    """Plots the sliding-window trend of beta_p with its CI."""
    plt.figure()
    if which_x == "S":
        x = trend_df["center_S"].values
        plt.xlabel("S (scale)")
    else:
        x = trend_df["center_lnS"].values
        plt.xlabel("ln(S)")

    y = trend_df["beta_p"].values
    lo = trend_df["beta_p_lo"].values
    hi = trend_df["beta_p_hi"].values

    # Plot the main trend line
    plt.plot(x, y, label=r"$\beta_p$ (windowed)", linewidth=2)

    # Plot the confidence interval band
    ok = np.isfinite(lo) & np.isfinite(hi)
    if np.any(ok):
        plt.fill_between(x[ok], lo[ok], hi[ok], alpha=0.2, label="CI band")

    plt.ylabel(r"$\beta_p$")
    plt.title(r"Trend of $\beta_p$ by scale (two-sided CI)")
    plt.grid(True, linestyle=':')
    plt.axhline(0, color='black', linewidth=0.7)
    plt.legend()
    plt.tight_layout()
    plt.savefig(outpath, dpi=200, bbox_inches="tight", transparent=transparent)
    plt.close()


def main():
    """Main function to parse arguments and run the analysis."""
    ap = argparse.ArgumentParser(
        description="Run scaling analysis using log-identity decomposition (T, G, S).",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument("--csv", dest="csv_path", required=True,
                    help="Path to the input CSV file")
    ap.add_argument("--t_col", required=True,
                    help="Column name for T (transport potential)")
    ap.add_argument("--g_col", required=True,
                    help="Column name for G (ground baseline)")
    ap.add_argument("--s_col", required=True,
                    help="Column name for S (scale variable, e.g., population)")
    ap.add_argument("--controls", nargs="*", default=[],
                    help="List of control variable column names")
    ap.add_argument("--p_col", default=None,
                    help="Optional: Column name for observed share p in (0,1)")
    ap.add_argument("--robust", default="HC3", choices=["HC0", "HC1", "HC2", "HC3", "HC4"],
                    help="Robust standard error type")
    ap.add_argument("--make_plots", action="store_true",
                    help="Generate and save output plots")
    ap.add_argument("--outdir", default=None,
                    help="Output directory for plots/CSVs (defaults to CSV's directory)")
    ap.add_argument("--transparent", action="store_true",
                    help="Save plots with a transparent background")
    ap.add_argument("--trend_window", type=int, default=12,
                    help="Sliding window size for trend analysis")
    ap.add_argument("--trend_step", type=int, default=1,
                    help="Sliding window step size")
    ap.add_argument("--trend_x", choices=["lnS", "S"], default="lnS",
                    help="X-axis for the trend plot ('S' or 'lnS')")
    ap.add_argument("--ci_alpha", type=float, default=0.05,
                    help="1 - confidence level; e.g., 0.05 for 95%, 0.01 for 99%")
    ap.add_argument("--no_cov_correction", action="store_true",
                    help="Disable covariance correction (use independence approx)")
    args = ap.parse_args()

    cfg = Config(
        csv_path=args.csv_path, t_col=args.t_col, g_col=args.g_col, s_col=args.s_col,
        controls=args.controls, p_col=args.p_col, robust=args.robust,
        make_plots=args.make_plots, outdir=args.outdir, transparent=args.transparent,
        trend_window=args.trend_window, trend_step=args.trend_step,
        trend_x=args.trend_x, ci_alpha=args.ci_alpha,
        use_cov_correction=(not args.no_cov_correction)
    )

    print(f"Loading data from: {cfg.csv_path}")
    df = pd.read_csv(cfg.csv_path)
    for col in [cfg.t_col, cfg.g_col, cfg.s_col] + cfg.controls:
        if col not in df.columns:
            raise ValueError(f"Missing column: {col}")

    # --- 1. Prepare data ---
    df["lnS"] = _safe_log(df[cfg.s_col])
    df["lnT"] = _safe_log(df[cfg.t_col])
    df["lnG"] = _safe_log(df[cfg.g_col])
    if cfg.p_col is not None:
        df["logitP"] = _safe_logit(df[cfg.p_col])

    # --- 2. Fit global models ---
    print("Fitting global models...")
    X_T = df[["lnS"] + cfg.controls]
    res_T = fit_ols(df["lnT"], X_T, robust=cfg.robust)
    beta_T = float(res_T.params.get("lnS", np.nan))

    X_G = df[["lnS"] + cfg.controls]
    res_G = fit_ols(df["lnG"], X_G, robust=cfg.robust)
    beta_G = float(res_G.params.get("lnS", np.nan))

    beta_p_implied = beta_T - beta_G

    print("\n" + "=" * 30)
    print("=== Log Identity Decomposition ===")
    print("Model 1: lnT ~ lnS + controls")
    print("=" * 30)
    print(res_T.summary())

    print("\n" + "=" * 30)
    print("Model 2: lnG ~ lnS + controls")
    print("=" * 30)
    print(res_G.summary())

    print("\n" + "=" * 30)
    print("--- Implied Exponent for Share (p = T/G) ---")
    print("=" * 30)
    print(f"beta_T = {beta_T:.4f}")
    print(f"beta_G = {beta_G:.4f}")
    print(f"beta_p = beta_T - beta_G = {beta_p_implied:.4f}")

    # --- 3. Generate plots and trend analysis ---
    if cfg.make_plots:
        print("\nGenerating plots and trend analysis...")
        outdir = ensure_outdir(cfg.outdir, cfg.csv_path)
        base_name = os.path.splitext(os.path.basename(cfg.csv_path))[0]

        f1 = os.path.join(outdir, f"{base_name}_lnT_fit.png")
        plot_lnS_vs_lnY(df, "lnS", "lnT", res_T, "ln(T)", f1, cfg.transparent)

        f2 = os.path.join(outdir, f"{base_name}_lnG_fit.png")
        plot_lnS_vs_lnY(df, "lnS", "lnG", res_G, "ln(G)", f2, cfg.transparent)

        f3 = os.path.join(outdir, f"{base_name}_betas.png")
        plot_beta_bars(beta_T, beta_G, f3, cfg.transparent)

        # --- 4. Sliding window trend analysis ---
        trend_df = compute_beta_p_trend(
            df, cfg.s_col, cfg.t_col, cfg.g_col, cfg.controls,
            window=cfg.trend_window, step=cfg.trend_step,
            robust=cfg.robust, ci_alpha=cfg.ci_alpha,
            use_cov_correction=cfg.use_cov_correction
        )
        f4 = os.path.join(outdir, f"{base_name}_beta_p_trend_ci.png")
        plot_beta_p_trend(trend_df, "S" if cfg.trend_x == "S" else "lnS", f4, cfg.transparent)

        print("\n[Saved outputs]")
        print(f"  - Plot: {f1}")
        print(f"  - Plot: {f2}")
        print(f"  - Plot: {f3}")
        print(f"  - Plot: {f4}")

        trend_csv = os.path.join(outdir, f"{base_name}_beta_p_trend_ci.csv")
        trend_df.to_csv(trend_csv, index=False, encoding="utf-8-sig")
        print(f"  - CSV:  {trend_csv}")


if __name__ == "__main__":
    main()