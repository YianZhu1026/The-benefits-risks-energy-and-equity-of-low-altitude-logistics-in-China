#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Population Grid Nearest Station Distance + Moran/LISA Analysis Script
(Supports Station CSVs)

Purpose:
1) Reads a population grid Shapefile and logistics station data (from CSV or vector).
2) Automatically projects data to a metric CRS (e.g., UTM) for distance
   calculation in meters.
3) Calculates the distance 'd' from each grid cell (centroid) to the
   nearest station. Applies a minimum distance floor (e.g., d < 250m -> d = 250m).
4) Calculates S = Population / d (S = NaN if Pop=0 or d<=0) and
   writes it back to the grid's attributes.
5) Performs Global Moran's I and Local Moran's I (LISA) analysis on
   the non-null 'S' values, using K-Nearest Neighbors (KNN) for weights.
6) **(Batch Mode)** Reads city names from a citydata.csv and replaces
   any occurrences of that city name in string columns with '{city}'
   for "sanitization" or templating.
7) Outputs:
   - Global Moran Summary: CSV (moran_global.csv)
   - **Moran Scatter Plot Data: CSV (moran_points.csv, with z and lag_z,
     ready for plotting in Origin, etc.)**
   - LISA Results: Shapefile (lisa_result.shp, with Ii, p-value,
     quadrant, and cluster type)

Output Description (moran_points.csv):
- grid_id: Index of the grid cell (matches grid_with_S.shp)
- S: Accessibility score (Population / distance)
- z: Standardized value (z-score) of S
- lag_z: Spatially lagged z-score (based on row-normalized KNN weights)
- d: Nearest station distance (meters)
- POP: Original population field value
- Ii, p_value, quad, sig, cl: LISA statistics and cluster type
- cx, cy: Grid centroid coordinates (in the output CRS)

Dependencies:
  pip install:
    pip install geopandas shapely pyproj pandas numpy scipy libpysal esda matplotlib
  or conda-forge:
    conda install -c conda-forge geopandas shapely pyproj pandas numpy scipy libpysal esda matplotlib

Usage Example (Stations from CSV):
  python this_script_name.py \
      --grid path/to/grid.shp \
      --stations-csv path/to/stations.csv \
      --csv-crs EPSG:4326 \
      --csv-x lon --csv-y lat \
      --pop-field POP \
      --out ./outputs \
      --neighbors 8 \
      --alpha 0.05 \
      --min-dist 250 \
      --city-csv path/to/citydata.csv

Usage Example (Stations from Vector, e.g., Shapefile):
  python this_script_name.py \
      --grid path/to/grid.shp \
      --stations path/to/stations.shp \
      --pop-field POP \
      --out ./outputs

CSV Notes:
- Explicitly specify coordinate columns with --csv-x and --csv-y.
- If not specified, the script auto-detects from {lon, longitude, x}
  and {lat, latitude, y}.
- CSV CRS defaults to WGS84 (EPSG:4326), changeable via --csv-crs.
"""

import os
import sys
import math
import argparse
import warnings
from typing import Tuple, Optional
import re
import os.path as osp
import re

import numpy as np
import pandas as pd
import geopandas as gpd
from shapely.geometry import Point
from pyproj import CRS
import matplotlib.pyplot as plt

# Import esda/libpysal with friendly error messages if missing
try:
    from esda.moran import Moran, Moran_Local
    from libpysal.weights import KNN
except ImportError:
    print("Error: Required libraries 'esda' and 'libpysal' not found.", file=sys.stderr)
    print("Please install them: pip install esda libpysal", file=sys.stderr)
    sys.exit(1)

# Import SciPy for KDTree (optional, provides speedup)
try:
    from scipy.spatial import cKDTree as KDTree

    SCIPY_OK = True
except Exception:
    SCIPY_OK = False
    warnings.warn(
        "SciPy not found. Falling back to GeoPandas sjoin_nearest for distance calculation, which may be slower.")

# Import SciPy for density plotting (optional)
try:
    from scipy.stats import gaussian_kde

    KDE_OK = True
except Exception:
    KDE_OK = False

warnings.filterwarnings("ignore", category=UserWarning)


def ensure_metric_crs(gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    """
    If GDF is in a geographic CRS (degrees), projects it to a suitable
    local UTM CRS (meters).
    """
    if gdf.crs is None:
        raise ValueError("Input data is missing CRS (Coordinate Reference System).")
    crs = CRS(gdf.crs)
    if crs.is_geographic:
        # Calculate centroid in lat/lon to determine UTM zone
        gdf_ll = gdf.to_crs(4326)
        centroid = gdf_ll.unary_union.centroid
        lon, lat = float(centroid.x), float(centroid.y)
        zone = int(math.floor((lon + 180) / 6) + 1)
        epsg = 32600 + zone if lat >= 0 else 32700 + zone  # N/S hemisphere
        return gdf.to_crs(epsg)
    return gdf


def to_points_gdf(gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    """Ensures the GDF is a Point layer; takes centroid for lines/polygons."""
    geom_type = gdf.geom_type.str.lower().unique()
    if any(t in ("point", "multipoint") for t in geom_type):
        return gdf
    # Get centroid for lines/polygons
    out = gdf.copy()
    out["geometry"] = out.geometry.centroid
    return out


def detect_xy_cols(df: pd.DataFrame, x_hint: Optional[str] = None, y_hint: Optional[str] = None) -> Tuple[
    Optional[str], Optional[str]]:
    """Auto-detects X/Y columns in a CSV, prioritizing explicit hints."""
    candidates_x = [x_hint, "lon", "longitude", "long", "lng", "log", "x", "Lon", "LONGITUDE", "LONG", "LNG", "LOG",
                    "X"]
    candidates_y = [y_hint, "lat", "latitude", "y", "Lat", "LATITUDE", "Y"]
    cols = set(df.columns)
    xcol = next((c for c in candidates_x if c and c in cols), None)
    ycol = next((c for c in candidates_y if c and c in cols), None)
    return xcol, ycol


def read_stations_to_crs(args, target_crs) -> gpd.GeoDataFrame:
    """Reads stations (from CSV or vector) and projects to target_crs."""
    if getattr(args, "stations_csv", None):
        # --- Load from CSV ---
        if getattr(args, "csv_delim", None):
            df = pd.read_csv(args.stations_csv, sep=args.csv_delim)
        else:
            # Use 'python' engine for auto-sniffing delimiter
            df = pd.read_csv(args.stations_csv, sep=None, engine="python")

        xcol, ycol = detect_xy_cols(df, getattr(args, "csv_x", None), getattr(args, "csv_y", None))
        if not xcol or not ycol:
            raise ValueError(
                f"Could not find coordinate columns in CSV. Use --csv-x/--csv-y or ensure columns like lon/lat/x/y exist. Found: {list(df.columns)[:20]}…")

        gdf = gpd.GeoDataFrame(df.copy(), geometry=gpd.points_from_xy(df[xcol], df[ycol]), crs=args.csv_crs)
        gdf = ensure_metric_crs(gdf).to_crs(target_crs)
        return gdf

    elif getattr(args, "stations", None):
        # --- Load from vector file ---
        gdf = gpd.read_file(args.stations)
        gdf = ensure_metric_crs(gdf).to_crs(target_crs)
        return gdf
    else:
        raise ValueError("Must provide either --stations-csv or --stations.")


def read_cities_from_csv(path: str) -> list[str]:
    """Reads a list of city names from a CSV. Prefers specific columns."""
    df = pd.read_csv(path)
    candidates = ["city", "city_name", "CityName", "City", "城市", "地市", "市"]
    cols = [c for c in candidates if c in df.columns]

    if not cols:
        if df.shape[1] == 1:
            # Fallback: use first column if it's the only one
            series = df.iloc[:, 0]
        else:
            raise ValueError(f"Could not find a city column in {path} (tried {candidates}).")
    else:
        series = df[cols[0]]

    cities = (
        series.dropna()
        .astype(str)
        .str.strip()
        .replace("", np.nan)
        .dropna()
        .unique()
        .tolist()
    )
    return cities


def infer_city_from_paths(paths: list[str]) -> Optional[str]:
    """Infers city name from paths, e.g., .../City/<Name>/..."""
    for p in paths:
        if not p:
            continue
        # Try to find .../City/Beijing/... pattern
        m = re.search(r"[\/](?:City|city)[\/ ]([^\/ ]+)", p)
        if m:
            cand = m.group(1)
            cand = re.sub(r"\.[^.]*$", "", cand)  # remove extension
            return cand

    # Fallback: check tokens in filename
    for p in paths:
        if not p:
            continue
        base = osp.basename(p)
        stem = re.sub(r"\.[^.]*$", "", base)
        tokens = re.split(r"[_\-\. ]+", stem)
        for t in tokens[::-1]:
            # Check for a plausible name
            if len(t) >= 3 and re.fullmatch(r"[A-Za-z一-龥]+", t) and t.lower() not in {"mesh", "grid", "points",
                                                                                      "stations", "dn", "coordinates",
                                                                                      "shp"}:
                return t
    return None


def sanitize_text_cols(gdf: gpd.GeoDataFrame, city: str, placeholder: str = "{city}") -> gpd.GeoDataFrame:
    """Replaces city name in all string columns with a placeholder."""
    if not city:
        return gdf
    pat = re.compile(re.escape(city), flags=re.IGNORECASE)
    out = gdf.copy()
    for col in out.columns:
        if col == "geometry":
            continue
        s = out[col]
        # Check if column is string or object type
        if pd.api.types.is_string_dtype(s) or s.dtype == object:
            # Convert to nullable 'string' type for .str accessor
            out[col] = s.astype("string").str.replace(pat, placeholder, regex=True)
    return out


def nearest_distance_centroid_to_points(grid: gpd.GeoDataFrame, stations: gpd.GeoDataFrame) -> np.ndarray:
    """Calculates Euclidean distance (meters) from grid centroid to nearest station."""
    centroids = grid.geometry.centroid
    grid_xy = np.vstack([centroids.x.values, centroids.y.values]).T

    stations_pt = to_points_gdf(stations)
    st_xy = np.vstack([stations_pt.geometry.x.values, stations_pt.geometry.y.values]).T

    if st_xy.shape[0] == 0:
        raise ValueError("Stations data is empty, cannot calculate distance.")

    if SCIPY_OK:
        # Use fast KDTree (from SciPy)
        tree = KDTree(st_xy)
        d, _ = tree.query(grid_xy, k=1)
        return d.astype(float)

    # Fallback: Use GeoPandas sjoin_nearest (slower)
    warnings.warn("Using GeoPandas sjoin_nearest. Install SciPy for faster distance calculation.")
    grid_pts = gpd.GeoDataFrame(grid.drop(columns=["geometry"]).copy(), geometry=centroids, crs=grid.crs)
    joined = gpd.sjoin_nearest(grid_pts, stations_pt[["geometry"]].copy(), how="left", distance_col="_dist")
    return joined["_dist"].astype(float).values


def build_knn_weights(gdf: gpd.GeoDataFrame, k: int) -> KNN:
    """Builds spatial weights based on K-Nearest Neighbors (KNN)."""
    c = gdf.geometry.centroid
    coords = np.column_stack([c.x.values, c.y.values])
    w = KNN.from_array(coords, k=k)
    w.transform = "R"  # Row-standardization
    return w


def classify_lisa(quadrant: int, sig: bool) -> str:
    """Classifies LISA results into cluster types."""
    if not sig:
        return "NotSig"
    return {1: "HH", 2: "LH", 3: "LL", 4: "HL"}.get(int(quadrant), "NotSig")


def make_moran_grid(items: list, out_path: str, cols: int = 4) -> None:
    """
    Draws a grid of Moran scatter plots (one per city).
    - Red regression line (through origin)
    - Grey zero-lines
    - Points colored by density (plasma cmap)
    """
    if not items:
        print("· No cities to plot. Skipping grid plot.")
        return

    rows = int(np.ceil(len(items) / cols))
    fig, axes = plt.subplots(rows, cols, figsize=(cols * 4.2, rows * 3.6))

    # Handle single plot cases
    if rows == 1 and cols == 1:
        axes = np.array([[axes]])
    elif rows == 1:
        axes = np.array([axes])
    elif cols == 1:
        axes = axes.reshape(rows, 1)

    for idx, it in enumerate(items):
        r, c = divmod(idx, cols)
        ax = axes[r, c]

        # Get data for this city
        z = np.asarray(it.get("z", []), dtype=float)
        lag_z = np.asarray(it.get("lag_z", []), dtype=float)
        moran_i = float(it.get("I", np.nan))
        p_val = float(it.get("p", np.nan))
        city = str(it.get("city", f"City{idx + 1}"))

        # Filter out invalid (NaN) points
        mask = np.isfinite(z) & np.isfinite(lag_z)
        z_valid = z[mask]
        lag_valid = lag_z[mask]

        # Scatter plot with density coloring (if KDE is available)
        if KDE_OK and z_valid.size > 1:
            try:
                xy = np.vstack([z_valid, lag_valid])
                kde = gaussian_kde(xy)
                dens = kde(xy)
                ax.scatter(z_valid, lag_valid, c=dens, cmap='plasma', s=8, alpha=0.9, linewidths=0)
            except Exception:
                ax.scatter(z_valid, lag_valid, s=8, alpha=0.6)  # Fallback
        else:
            ax.scatter(z_valid, lag_valid, s=8, alpha=0.6)

        # Red regression line (slope ≈ Moran's I)
        denom = float(np.nansum(z_valid * z_valid))
        slope = float(np.nansum(z_valid * lag_valid) / denom) if denom > 0 else moran_i

        if z_valid.size >= 2:
            x_min, x_max = np.nanpercentile(z_valid, [1, 99])
            if not np.isfinite(x_min) or not np.isfinite(x_max) or x_min == x_max:
                x_min, x_max = z_valid.min(), z_valid.max()
        else:
            x_min, x_max = -1.0, 1.0

        xs = np.linspace(x_min, x_max, 100)
        ax.plot(xs, slope * xs, linewidth=1.6, color='red')

        # Grey zero-lines
        ax.axhline(0, linestyle='--', linewidth=0.9, color='gray')
        ax.axvline(0, linestyle='--', linewidth=0.9, color='gray')

        # Annotations
        sig_text = "p<0.01" if (np.isfinite(p_val) and p_val < 0.01) else (
            f"p={p_val:.3f}" if np.isfinite(p_val) else "p=NA")
        ax.set_title(f"{city}")
        ax.text(0.02, 0.95, f"I={moran_i:.3f}\n{sig_text}", transform=ax.transAxes,
                ha='left', va='top')

    # Hide empty subplots
    total_plots = rows * cols
    for k in range(len(items), total_plots):
        r, c = divmod(k, cols)
        axes[r, c].axis('off')

    plt.tight_layout()
    fig.savefig(out_path, dpi=200, bbox_inches='tight')
    plt.close(fig)
    print(f"· Moran scatter plot grid saved: {out_path}")


def run_for_city(city: str, args) -> dict:
    """
    Runs the full analysis pipeline for a single city.
    This function is used by the batch processing mode.
    """
    base = args.base_dir
    lower = city.lower()
    grid_path = osp.join(base, city, "mesh", f"mesh_{lower}.shp")
    stations_csv_path = osp.join(base, city, "DN_coordinates.csv")
    out_dir = osp.join(base, city, "outputsMoran")

    # --- 1) Read Grid ---
    if not osp.exists(grid_path):
        raise FileNotFoundError(f"Grid file not found: {grid_path}")
    grid = gpd.read_file(grid_path)
    if args.pop_field not in grid.columns:
        raise KeyError(f"{city}: Population field '{args.pop_field}' not found.")

    # --- 2) Read Stations CSV ---
    if not osp.exists(stations_csv_path):
        raise FileNotFoundError(f"Stations CSV not found: {stations_csv_path}")
    df_st = pd.read_csv(stations_csv_path, sep=args.csv_delim or None, engine="python")

    # Use 'log'/'lat' as default hints for batch mode
    x_hint = args.csv_x or "log"
    y_hint = args.csv_y or "lat"
    xcol, ycol = detect_xy_cols(df_st, x_hint, y_hint)
    if not xcol or not ycol:
        raise ValueError(
            f"{city}: Stations CSV missing coordinate columns (tried {x_hint}/{y_hint}). Found: {list(df_st.columns)[:20]}…")

    # --- 3) Project CRS ---
    grid_m = ensure_metric_crs(grid)
    st_gdf = gpd.GeoDataFrame(df_st.copy(), geometry=gpd.points_from_xy(df_st[xcol], df_st[ycol]), crs=args.csv_crs)
    st_m = ensure_metric_crs(st_gdf).to_crs(grid_m.crs)

    # --- 4) Sanitize Text (Optional) ---
    grid_m = sanitize_text_cols(grid_m, city)
    st_m = sanitize_text_cols(st_m, city)

    # --- 5) Calculate Distance 'd' ---
    d = nearest_distance_centroid_to_points(grid_m, st_m)
    min_d = float(args.min_dist)
    d = np.where(~np.isfinite(d), min_d, np.maximum(d, min_d))
    grid_m["d"] = d

    # --- 6) Calculate Score 'S' = POP / d ---
    pop = pd.to_numeric(grid_m[args.pop_field], errors="coerce").fillna(0.0).values
    with np.errstate(divide='ignore', invalid='ignore'):
        # S = Pop / d, but only where Pop > 0 and d > 0
        s = np.where((pop > 0) & (d > 0), pop / d, np.nan)
    grid_m["S"] = s

    # --- 7) Save Intermediate Grid ---
    os.makedirs(out_dir, exist_ok=True)
    out_grid_path = osp.join(out_dir, "grid_with_S.shp")
    export_cols = [c for c in grid_m.columns if c != "geometry"] + ["geometry"]
    grid_m[export_cols].to_file(out_grid_path, driver="ESRI Shapefile")

    # --- 8) Run Moran/LISA ---
    sub = grid_m[grid_m["S"].notna()].copy()
    if len(sub) < 3:
        print(f"{city}: Too few valid samples (n < 3) with S != NaN. Skipping Moran/LISA.")
        return None

    w = build_knn_weights(sub, k=args.neighbors)
    y = sub["S"].values.astype(float)

    # Global Moran
    moran = Moran(y, w, permutations=999)
    moran_df = pd.DataFrame({
        "city": [city], "n": [int(moran.n)], "k": [int(args.neighbors)],
        "I": [float(moran.I)], "EI": [float(getattr(moran, "EI", np.nan))],
        "VI_norm": [float(getattr(moran, "VI_norm", np.nan))],
        "z_norm": [float(getattr(moran, "z_norm", np.nan))],
        "p_norm": [float(getattr(moran, "p_norm", np.nan))],
        "z_sim": [float(getattr(moran, "z_sim", np.nan))],
        "p_sim": [float(getattr(moran, "p_sim", np.nan))],
        "permutations": [999]
    })
    moran_df.to_csv(osp.join(out_dir, "moran_global.csv"), index=False)

    # Local Moran (LISA)
    lisa = Moran_Local(y, w, permutations=999)
    alpha = float(args.alpha)
    sig = (lisa.p_sim < alpha)

    # Get standardized z and lag_z for scatter plot
    try:
        z = getattr(moran, "z")
    except Exception:
        z = (y - y.mean()) / y.std(ddof=1)
    try:
        lag_z = w.sparse.dot(z)
    except Exception:  # Fallback for non-sparse or older versions
        lag_vals = []
        for i in range(len(z)):
            neigh = w.neighbors.get(i, [])
            if not neigh:
                lag_vals.append(np.nan);
                continue
            weights = w.weights.get(i, [1.0] * len(neigh))
            ssum = float(np.sum(weights))
            lag_vals.append(np.nan if ssum <= 0 else np.sum(np.array(weights) * z[np.array(neigh)]) / ssum)
        lag_z = np.array(lag_vals)

    # Save scatter plot data to CSV
    c = sub.geometry.centroid
    points_df = pd.DataFrame({
        "city": city, "grid_id": sub.index.values, "S": y, "z": z, "lag_z": lag_z,
        "d": sub["d"].values, "POP": pd.to_numeric(sub[args.pop_field], errors="coerce").values,
        "Ii": lisa.Is.astype(float), "p_value": lisa.p_sim.astype(float),
        "quad": lisa.q.astype(int), "sig": sig.astype(int),
        "cl": [classify_lisa(q, s) for q, s in zip(lisa.q.astype(int), sig)],
        "cx": c.x.values, "cy": c.y.values, "k": int(args.neighbors)
    })
    points_df.to_csv(osp.join(out_dir, "moran_points.csv"), index=False)

    # Save LISA results to Shapefile
    sub["Ii"] = lisa.Is.astype(float)
    sub["p_value"] = lisa.p_sim.astype(float)
    sub["quad"] = lisa.q.astype(int)
    sub["sig"] = sig.astype(int)
    sub["cl"] = [classify_lisa(q, s) for q, s in zip(sub["quad"].values, sig)]
    lisa_cols = ["d", "S", "Ii", "p_value", "quad", "sig", "cl", "geometry"]
    gpd.GeoDataFrame(sub[lisa_cols], geometry="geometry", crs=sub.crs).to_file(
        osp.join(out_dir, "lisa_result.shp"), driver="ESRI Shapefile")

    # Return data for the summary plot
    result = {
        "city": city, "z": z, "lag_z": lag_z,
        "I": float(moran.I), "p": float(getattr(moran, "p_sim", np.nan)),
    }
    print(f"{city}: Analysis complete -> {out_dir}")
    return result


def main():
    """
    Main function to parse arguments and run the analysis.
    """
    parser = argparse.ArgumentParser(description="Grid Nearest Station Distance + Moran/LISA Analysis (CSV supported)")

    # --- Single City Mode Args ---
    parser.add_argument("--grid", required=False, help="Path to population grid Shapefile (for single-city mode)")
    parser.add_argument("--stations", required=False, help="Path to stations vector file (e.g., .shp, .gpkg)")
    parser.add_argument("--stations-csv", required=False, help="Path to stations CSV file (alternative to --stations)")
    parser.add_argument("--out", required=False, help="Output directory (for single-city mode)")
    parser.add_argument("--city", required=False, default=None,
                        help="City name (for single-city mode, used for sanitization)")

    # --- Batch City Mode Args ---
    parser.add_argument("--city-csv", required=False, help="CSV file listing cities to process (e.g., citydata.csv)")
    parser.add_argument("--base-dir", required=False, default="Data/City",
                        help="Base directory for city data (default: Data/City)")

    # --- Common CSV & Analysis Args ---
    parser.add_argument("--csv-x", required=False, default=None,
                        help="X/longitude column in CSV (default: auto-detect 'lon', 'log', 'x')")
    parser.add_argument("--csv-y", required=False, default=None,
                        help="Y/latitude column in CSV (default: auto-detect 'lat', 'y')")
    parser.add_argument("--csv-crs", required=False, default="EPSG:4326",
                        help="CRS of input CSV coordinates (default: EPSG:4326)")
    parser.add_argument("--csv-delim", required=False, default=None, help="Delimiter for CSV (default: auto-detect)")

    parser.add_argument("--pop-field", required=True, help="Population field name in grid (e.g., 'value_12', 'POP')")
    parser.add_argument("--neighbors", type=int, default=8, help="Number of neighbors (k) for KNN/LISA (default: 8)")
    parser.add_argument("--alpha", type=float, default=0.05, help="Significance level (alpha) for LISA (default: 0.05)")
    parser.add_argument("--min-dist", type=float, default=250.0,
                        help="Minimum distance floor (meters) (default: 250.0)")

    args = parser.parse_args()

    # --- Workflow 1: Batch Mode ---
    if args.city_csv:
        cities = read_cities_from_csv(args.city_csv)
        if not cities:
            raise ValueError("No city names found in citydata.csv.")
        print(f"Batch mode activated. Processing {len(cities)} cities: {cities}")

        plot_items = []
        for city in cities:
            try:
                result_data = run_for_city(str(city), args)
                if result_data:
                    plot_items.append(result_data)
            except Exception as e:
                print(f"[ERROR] Failed processing {city}: {e}", file=sys.stderr)

        # Create composite scatter plot grid
        grid_png_path = osp.join(args.base_dir, "moran_scatter_grid.png")
        make_moran_grid(plot_items, grid_png_path, cols=5)
        print("All cities processed.")
        return

    # --- Workflow 2: Single City Mode ---
    if not args.grid or (not args.stations and not args.stations_csv) or not args.out:
        raise ValueError("Single-city mode requires --grid, --out, and one of --stations or --stations-csv.")

    os.makedirs(args.out, exist_ok=True)

    print("[1/7] Reading data...")
    grid = gpd.read_file(args.grid)

    if args.pop_field not in grid.columns:
        raise KeyError(f"Population field '{args.pop_field}' not found in grid.")

    print("[2/7] Projecting to metric CRS (if needed)...")
    grid_m = ensure_metric_crs(grid)
    stations_m = read_stations_to_crs(args, grid_m.crs)

    # Infer city name and sanitize text columns
    city_name = args.city
    if not city_name:
        city_name = infer_city_from_paths(
            [args.grid, getattr(args, "stations", None), getattr(args, "stations_csv", None), args.out])

    if city_name:
        print(f"· Identified city: {city_name}. Sanitizing string fields...")
        grid_m = sanitize_text_cols(grid_m, city_name)
        stations_m = sanitize_text_cols(stations_m, city_name)

    print(f"[3/7] Calculating nearest station distance 'd' (min {args.min_dist}m)...")
    d = nearest_distance_centroid_to_points(grid_m, stations_m)
    min_d = float(args.min_dist)
    d = np.where(~np.isfinite(d), min_d, np.maximum(d, min_d))
    grid_m["d"] = d

    print("[4)7] Calculating accessibility score 'S' (Population / d)...")
    pop = pd.to_numeric(grid_m[args.pop_field], errors="coerce").fillna(0.0).values
    with np.errstate(divide='ignore', invalid='ignore'):
        s = np.where((pop > 0) & (d > 0), pop / d, np.nan)
    grid_m["S"] = s

    out_grid_path = os.path.join(args.out, "grid_with_S.shp")
    print(f"[5/7] Exporting grid with 'd' and 'S' to: {out_grid_path}")
    export_cols = [c for c in grid_m.columns if c not in ("geometry",)] + ["geometry"]
    grid_m[export_cols].to_file(out_grid_path, driver="ESRI Shapefile")

    sub = grid_m[grid_m["S"].notna()].copy()
    if len(sub) < 3:
        raise ValueError("Too few valid samples (n < 3) with S != NaN. Cannot run spatial analysis.")

    print(f"[6/7] Building KNN weights (k={args.neighbors}) and running Moran's I / LISA...")
    w = build_knn_weights(sub, k=args.neighbors)
    y = sub["S"].values.astype(float)

    # Global Moran
    moran = Moran(y, w, permutations=999)
    moran_df = pd.DataFrame({
        "n": [int(moran.n)], "k": [int(args.neighbors)],
        "I": [float(moran.I)], "EI": [float(getattr(moran, "EI", np.nan))],
        "VI_norm": [float(getattr(moran, "VI_norm", np.nan))],
        "z_norm": [float(getattr(moran, "z_norm", np.nan))],
        "p_norm": [float(getattr(moran, "p_norm", np.nan))],
        "z_sim": [float(getattr(moran, "z_sim", np.nan))],
        "p_sim": [float(getattr(moran, "p_sim", np.nan))],
        "permutations": [999]
    })
    moran_csv = os.path.join(args.out, "moran_global.csv")
    moran_df.to_csv(moran_csv, index=False)
    print(f"  · Global Moran CSV saved: {moran_csv}")

    # Local Moran (LISA)
    lisa = Moran_Local(y, w, permutations=999)
    alpha = float(args.alpha)
    sig = (lisa.p_sim < alpha)

    # Get z and lag_z for scatter plot
    try:
        z = getattr(moran, "z")
    except Exception:
        z = (y - y.mean()) / y.std(ddof=1)

    try:
        lag_z = w.sparse.dot(z)
    except Exception:  # Fallback
        lag_vals = []
        for i in range(len(z)):
            neigh = w.neighbors.get(i, [])
            if not neigh:
                lag_vals.append(np.nan);
                continue
            weights = w.weights.get(i, [1.0] * len(neigh))
            ssum = float(np.sum(weights))
            lag_vals.append(np.nan if ssum <= 0 else np.sum(np.array(weights) * z[np.array(neigh)]) / ssum)
        lag_z = np.array(lag_vals)

    # Save scatter plot data to CSV
    c = sub.geometry.centroid
    points_df = pd.DataFrame({
        "grid_id": sub.index.values, "S": y, "z": z, "lag_z": lag_z,
        "d": sub["d"].values, "POP": pd.to_numeric(sub[args.pop_field], errors="coerce").values,
        "Ii": lisa.Is.astype(float), "p_value": lisa.p_sim.astype(float),
        "quad": lisa.q.astype(int), "sig": sig.astype(int),
        "cl": [classify_lisa(q, s) for q, s in zip(lisa.q.astype(int), sig)],
        "cx": c.x.values, "cy": c.y.values, "k": int(args.neighbors)
    })
    moran_points_csv = os.path.join(args.out, "moran_points.csv")
    points_df.to_csv(moran_points_csv, index=False)
    print(f"  · Moran scatter plot data CSV saved: {moran_points_csv}")

    # Save LISA results to Shapefile
    sub["Ii"] = lisa.Is.astype(float)
    sub["p_value"] = lisa.p_sim.astype(float)
    sub["quad"] = lisa.q.astype(int)
    sub["sig"] = sig.astype(int)
    sub["cl"] = [classify_lisa(q, s) for q, s in zip(sub["quad"].values, sig)]
    lisa_cols = ["d", "S", "Ii", "p_value", "quad", "sig", "cl", "geometry"]
    lisa_gdf = sub[lisa_cols].copy()
    lisa_out = os.path.join(args.out, "lisa_result.shp")
    lisa_gdf.to_file(lisa_out, driver="ESRI Shapefile")
    print(f"  · LISA results Shapefile saved: {lisa_out}")

    # Create single-city scatter plot
    single_plot_png = os.path.join(args.out, "moran_scatter_grid.png")
    plot_items = [{
        "city": city_name or "City",
        "z": z, "lag_z": lag_z,
        "I": float(moran.I), "p": float(getattr(moran, "p_sim", np.nan)),
    }]
    make_moran_grid(plot_items, single_plot_png, cols=1)

    print("[7/7] Analysis complete!")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"[ERROR] An error occurred: {e}", file=sys.stderr)
        sys.exit(1)