# -*- coding: utf-8 -*-
"""
ArcPy Script: Summarize Hourly Risk by Land Use Type

This script calculates the total hourly risk by land use category based
on a specific, multi-stage geoprocessing workflow.

!!! NOTE: This script follows a precise, user-defined workflow:
1. Intersect (Grid + Landuse) -> intersect_1
2. Calculate Area on intersect_1 -> 'Area'
3. Spatial Join (Grid + intersect_1) -> join_result (sums 'Area')
4. Intersect (join_result + Landuse) -> intersect_2
5. Calculate Area on intersect_2 -> 'IArea'
6. Calculate Hourly Risk on intersect_2 (using 'Area', 'IArea', and 'risk_##')
7. Summarize Risk by Class
8. Export to CSV
"""

import arcpy
import os
import csv
from datetime import datetime

# ---------------- CONFIGURATION ----------------
# --- Basic Parameters ---
CITY_NAME = "Beijing"
# A specific index value used in the risk calculation formula
RISK_INDEX = 7.871299293

# --- Paths ---
WORKSPACE = f"F:/ResearchData/05-Paper/05_UAV4NC_2025/Code/Data/City/{CITY_NAME}/"
OUTPUT_DIR = os.path.join(WORKSPACE, "Landuse")

# Input Feature Classes
GRID_FC = os.path.join(WORKSPACE, "risk.shp")  # 1km grid (with risk_00..risk_23)
LANDUSE_FC = os.path.join(WORKSPACE, "Landuse", "EULUC.shp")  # Land use (with class field)

# Intermediate & Output Files
# 1. First intersect output
INTERSECT_FC_1 = os.path.join(OUTPUT_DIR, "EULUC_Intersect.shp")
# 2. Spatial join output
JOIN_RESULT_FC = os.path.join(OUTPUT_DIR, "grid_join.shp")
# 3. Second intersect output
INTERSECT_FC_2 = os.path.join(OUTPUT_DIR, "result.shp")
# 4. Summary table
OUTPUT_TABLE_DBF = os.path.join(OUTPUT_DIR, "LandUse_Risk_Summary.dbf")
# 5. Final CSV
FINAL_CSV_PATH = os.path.join(OUTPUT_DIR, "LandUse_Risk_Summary.csv")

# --- Field Names ---
# The field in LANDUSE_FC that contains the land use type/class
LANDUSE_CLASS_FIELD = "Level2"
# Field name for the area from the FIRST intersect
AREA_FIELD_1 = "Area"
# Field name for the area from the SECOND intersect
AREA_FIELD_2 = "IArea"


# ------------------------------------------------


# ---------------- Utility Functions ----------------

def find_field_case_insensitive(dataset, target_name):
    """
    Finds the actual name of a field in a dataset, ignoring case.
    Returns the actual field name or None if not found.
    """
    target_lower = target_name.lower()
    for field in arcpy.ListFields(dataset):
        if field.name.lower() == target_lower:
            return field.name
    return None


def ensure_geodesic_area(input_fc, area_field="Area"):
    """
    Adds a field (if it doesn't exist) and calculates its geodesic area
    in SQUARE_METERS.
    """
    if not find_field_case_insensitive(input_fc, area_field):
        arcpy.AddField_management(input_fc, area_field, "DOUBLE")

    arcpy.CalculateGeometryAttributes_management(
        in_features=input_fc,
        geometry_property=[[area_field, "AREA_GEODESIC"]],
        area_unit="SQUARE_METERS"
    )
    return area_field


# ---------------- Workflow Step 1: Initial Intersect ----------------

def run_initial_intersect():
    """
    Performs the first intersect analysis between the risk grid and land use.
    This corresponds to the original 'intersect_analysis' function.
    """
    arcpy.AddMessage("Step 1: Running initial Intersect (Grid + Landuse)...")
    if not arcpy.Exists(GRID_FC):
        arcpy.AddError(f"Grid data not found: {GRID_FC}")
        return None
    if not arcpy.Exists(LANDUSE_FC):
        arcpy.AddError(f"Land use data not found: {LANDUSE_FC}")
        return None

    arcpy.Intersect_analysis(
        in_features=[GRID_FC, LANDUSE_FC],
        out_feature_class=INTERSECT_FC_1,
        join_attributes="ALL",
        output_type="INPUT"
    )
    # Calculate geodesic area for the resulting slivers
    ensure_geodesic_area(INTERSECT_FC_1, AREA_FIELD_1)
    return INTERSECT_FC_1


# ---------------- Workflow Step 2: Spatial Join ----------------

def run_spatial_join():
    """
    Performs a spatial join from the grid (target) to the first
    intersect (join), summing the 'Area' field.
    This corresponds to the original 'Jiont' function.
    """
    arcpy.AddMessage("Step 2: Running Spatial Join (Grid JOIN Intersect)...")

    # Create field mappings to sum the 'Area' from the intersect
    # and carry over the 'risk_##' fields from the grid.
    field_mappings = arcpy.FieldMappings()

    # Add risk fields from the grid
    for h in range(24):
        field_name = f"risk_{h:02d}"
        field_map = arcpy.FieldMap()
        field_map.addInputField(GRID_FC, field_name)
        field_mappings.addFieldMap(field_map)

    # Add the 'Area' field from the intersect and set merge rule to SUM
    field_map_area = arcpy.FieldMap()
    field_map_area.addInputField(INTERSECT_FC_1, AREA_FIELD_1)
    field_map_area.mergeRule = "SUM"
    field_mappings.addFieldMap(field_map_area)

    # Execute the spatial join
    arcpy.analysis.SpatialJoin(
        target_features=GRID_FC,
        join_features=INTERSECT_FC_1,
        out_feature_class=JOIN_RESULT_FC,
        join_type="KEEP_ALL",
        join_operation="JOIN_ONE_TO_ONE",
        match_option="CONTAINS",
        field_mapping=field_mappings
    )
    return JOIN_RESULT_FC


# ---------------- Workflow Step 4: Calculate Hourly Risk ----------------
# (Note: Step 3 is the second intersect, performed in main())

def calculate_hourly_risk(input_fc, risk_index):
    """
    Calculates the hourly risk using the complex formula from the user.
    This function expects 'Area', 'IArea', 'Level2', and 'risk_##' fields.
    """
    arcpy.AddMessage("Step 4: Calculating hourly risk values...")

    # Find all required fields (case-insensitive)
    class_field = find_field_case_insensitive(input_fc, LANDUSE_CLASS_FIELD)
    # 'Area' (from first intersect, summed by spatial join)
    area_field_1 = find_field_case_insensitive(input_fc, AREA_FIELD_1)
    # 'IArea' (from second intersect)
    area_field_2 = find_field_case_insensitive(input_fc, AREA_FIELD_2)

    if not all([class_field, area_field_1, area_field_2]):
        arcpy.AddError(f"Missing required fields: '{LANDUSE_CLASS_FIELD}', '{AREA_FIELD_1}', or '{AREA_FIELD_2}'.")
        return None, None, None

    # Find all 'risk_##' source fields
    risk_src_fields = []
    for h in range(24):
        field_name = f"risk_{h:02d}"
        real_name = find_field_case_insensitive(input_fc, field_name)
        if real_name is None:
            arcpy.AddError(f"Missing required risk field: {field_name}.")
            return None, None, None
        risk_src_fields.append(real_name)

    # Create short temporary field names (e.g., 'r00') for calculation
    # to avoid Shapefile 10-character limit issues.
    temp_fields = []
    for h in range(24):
        tmp_field = f"r{h:02d}"  # e.g., 'r00', 'r01' ... 'r23'
        if find_field_case_insensitive(input_fc, tmp_field) is None:
            arcpy.AddField_management(input_fc, tmp_field, "DOUBLE")

        # This is the core formula from the original script
        # It uses 'IArea' (Area_Field_2) and 'Area' (Area_Field_1)
        expression = (
            f"!{risk_src_fields[h]}! * !{area_field_2}! * {risk_index} / "
            f"(!{area_field_1}! * 500 * 500 * 10000)"
        )

        arcpy.CalculateField_management(input_fc, tmp_field, expression, "PYTHON3")
        temp_fields.append(tmp_field)

    return class_field, temp_fields, area_field_1  # Returns the 'class' and 'temp' fields


# ---------------- Workflow Step 5: Summary Statistics ----------------

def summarize_risk(input_fc, temp_fields, class_field):
    """
    Generates a DBF table by summarizing (SUM) the temporary risk fields,
    grouped by the land use class field.
    """
    arcpy.AddMessage("Step 5: Summarizing risk totals by land use class...")

    # Define statistics: SUM of all 'r##' fields
    stats_fields = [[field, "SUM"] for field in temp_fields]

    arcpy.Statistics_analysis(
        in_table=input_fc,
        out_table=OUTPUT_TABLE_DBF,
        statistics_fields=stats_fields,
        case_field=class_field
    )

    # Clean up temporary fields (r00...r23) from the analysis layer
    for field in temp_fields:
        try:
            arcpy.DeleteField_management(input_fc, field)
        except Exception:
            pass  # Ignore if deletion fails

    return OUTPUT_TABLE_DBF


# ---------------- Workflow Step 6: Write Final CSV ----------------

def write_csv_from_dbf(dbf_path, class_field):
    """
    Reads the output DBF and writes it to a clean CSV file.
    Handles field name truncation (e.g., 'SUM_r00' -> 'SUM_r0').
    """
    arcpy.AddMessage("Step 6: Exporting summary table to CSV...")

    # Expected DBF summary field names (e.g., 'SUM_r00')
    sum_field_prefixes = [f"SUM_r{h:02d}" for h in range(24)]

    # Find the *actual* (case-insensitive, truncated) field names in the DBF
    dbf_fields = [f.name for f in arcpy.ListFields(dbf_path)]

    def find_real_dbf_field(name_prefix):
        """Finds the real DBF field, handling truncation."""
        low = name_prefix.lower()
        for f in dbf_fields:
            if f.lower() == low:
                return f
        # Handle possible truncation (e.g., 'SUM_r0' instead of 'SUM_r00')
        for f in dbf_fields:
            if f.lower().startswith(low):
                return f
        return None

    # Get the real field names from the DBF table
    real_class_field = find_field_case_insensitive(dbf_path, class_field) or class_field
    real_sum_fields = [find_real_dbf_field(name) for name in sum_field_prefixes]

    if any(v is None for v in real_sum_fields):
        arcpy.AddWarning("Could not match all summary fields in DBF, likely due to truncation.")

    # Read DBF and write to CSV
    header = ["Landuse_Class"] + [f"Risk_Hour_{h:02d}" for h in range(24)] + ["Process_Timestamp"]

    with open(FINAL_CSV_PATH, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(header)

        # Build the list of fields to read from the cursor
        fields_to_read = [real_class_field] + [f for f in real_sum_fields if f is not None]

        with arcpy.da.SearchCursor(dbf_path, fields_to_read) as cursor:
            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            for row in cursor:
                # Replace None with 0 for cleaner output
                values = [row[0]] + [(0 if (r is None) else r) for r in row[1:]] + [now_str]
                writer.writerow(values)

    arcpy.AddMessage(f"CSV file saved to: {FINAL_CSV_PATH}")
    return FINAL_CSV_PATH


# ---------------- Main Workflow ----------------
def main():
    """
    Executes the full, user-defined geoprocessing workflow.
    """
    start = datetime.now()
    arcpy.env.overwriteOutput = True
    arcpy.env.workspace = WORKSPACE
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    arcpy.AddMessage(f"Starting risk summary process for {CITY_NAME}...")

    try:
        # Step 1: Run initial intersect (Grid + Landuse)
        # Original: fc = intersect_analysis()
        fc_1 = run_initial_intersect()
        if not fc_1 or not arcpy.Exists(fc_1):
            arcpy.AddError("Initial Intersect failed. Aborting.")
            return

        # Step 2: Run spatial join (Grid JOIN fc_1)
        # Original: result_fc = Jiont()
        joined_fc = run_spatial_join()
        if not joined_fc or not arcpy.Exists(joined_fc):
            arcpy.AddError("Spatial Join failed. Aborting.")
            return

        # Step 3: Run second intersect (joined_fc + Landuse)
        # Original: r_fc = ...
        arcpy.AddMessage("Step 3: Running second Intersect (JoinResult + Landuse)...")
        arcpy.Intersect_analysis(
            in_features=[joined_fc, LANDUSE_FC],
            out_feature_class=INTERSECT_FC_2,
            join_attributes="ALL",
            output_type="INPUT"
        )

        # Step 3b: Calculate area for the final slivers
        ensure_geodesic_area(INTERSECT_FC_2, AREA_FIELD_2)

        # Step 4: Calculate hourly risk values on the final layer (INTERSECT_FC_2)
        arcpy.AddMessage("Step 4: Calculating hourly risk values...")
        class_field, temp_fields, area_field = calculate_hourly_risk(INTERSECT_FC_2, RISK_INDEX)
        if not temp_fields:
            arcpy.AddError("Hourly risk calculation failed. Aborting.")
            return

        # Step 5: Summarize risk totals by land use class
        arcpy.AddMessage("Step 5: Summarizing risk totals by land use class...")
        dbf_path = summarize_risk(INTERSECT_FC_2, temp_fields, class_field)
        if not dbf_path or not arcpy.Exists(dbf_path):
            arcpy.AddError("Statistics summary failed. Aborting.")
            return
        arcpy.AddMessage(f"Intermediate DBF table generated: {dbf_path}")

        # Step 6: Export final results to CSV
        arcpy.AddMessage("Step 6: Exporting results to CSV...")
        write_csv_from_dbf(dbf_path, class_field)

        duration = (datetime.now() - start).total_seconds()
        arcpy.AddMessage(f"\nProcessing complete!")
        arcpy.AddMessage(f"Total time: {duration:.2f} seconds")
        arcpy.AddMessage(f"DBF: {dbf_path}")
        arcpy.AddMessage(f"CSV: {FINAL_CSV_PATH}")

    except arcpy.ExecuteError:
        arcpy.AddError(arcpy.GetMessages(2))
    except Exception as e:
        arcpy.AddError(f"An unexpected error occurred: {e}")
        import traceback
        arcpy.AddError(traceback.format_exc())


if __name__ == "__main__":
    main()