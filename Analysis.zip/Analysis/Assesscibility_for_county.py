# -*- coding: utf-8 -*-
"""
Hourly Weighted Gini Coefficient Calculator for Accessibility by District

This script calculates the "logistics fairness" (weighted Gini coefficient)
of accessibility, defined as (Population / Distance to Nearest Station).
It performs this calculation for each hour (using 'value_00'...'value_23'
fields) and for each administrative district (County).

Dependencies:
  pip install geopandas shapely pandas numpy scipy

Data Assumptions (can be changed in the CONFIGURATION section):
  - Stations CSV: Data/City/{City}/DN_coordinates.csv (cols: 'log' or 'lon', 'lat')
  - Grid SHP:     Data/City/{City}/mesh/mesh_{lower_city}.shp (cols: 'value_00'...'value_23')
  - Districts SHP: Data/City/{City}/County/County.shp (must have a district name field)

Output:
  Data/City/{City}/County/fairness_by_district.csv

Notes:
  - Gini Coefficient is in the range [0, 1]. 0 = perfect equality.
  - The script automatically selects a metric projection (e.g., UTM)
    based on the data's centroid to ensure distances are in meters.
"""

import os
import sys
import numpy as np
import pandas as pd
import geopandas as gpd
from shapely.geometry import Point
from scipy.spatial import cKDTree

# ======================= CONFIGURATION =======================
CITY_NAME = "Zhengzhou"
LOWER_CITY_NAME = CITY_NAME.lower()

BASE_DIR = f"Data/City/{CITY_NAME}"
GRID_SHP_PATH = f"{BASE_DIR}/mesh/mesh_{LOWER_CITY_NAME}.shp"
LOGISTICS_CSV_PATH = f"{BASE_DIR}/DN_coordinates.csv"
DISTRICT_SHP_PATH = f"{BASE_DIR}/County/County.shp"
OUTPUT_CSV_PATH = f"{BASE_DIR}/County/fairness_by_district.csv"

# Candidates for the district name field in the District Shapefile.
# The script will try these names in order.
# If none are found, it defaults to the first available string (object) field.
# !!! YOU MUST UPDATE THIS to match your file !!!
DISTRICT_NAME_FIELD_CANDIDATES = ["DIST_NAME", "County_NM", "Name"]

# Minimum distance (in meters) to use.
# Avoids division-by-zero if a station is inside a grid cell.
DISTANCE_FLOOR_METERS = 50.0


# =============================================================


def auto_select_metric_crs(gdf: gpd.GeoDataFrame) -> "pyproj.CRS":
    """
    Selects an appropriate metric (meter-based) CRS.
    - If CRS is already projected and in meters, returns it.
    - If CRS is geographic (lat/lon), estimates the best local UTM zone.
    - As a fallback, uses EPSG:3857 (Web Mercator).
    """
    if gdf.crs is not None and not gdf.crs.is_geographic:
        if gdf.crs.axis_info[0].unit_name.lower() in ("metre", "meter"):
            return gdf.crs

    # Reproject to 4326 to get a standard lat/lon centroid
    g_ll = gdf.to_crs(4326) if gdf.crs is not None else gdf.set_crs(4326, allow_override=True)

    # Get centroid to estimate UTM zone
    # Use unary_union for a robust centroid of the whole geometry set
    try:
        c = g_ll.unary_union.centroid
        lon, lat = float(c.x), float(c.y)

        # Calculate UTM zone
        zone = int((lon + 180) // 6) + 1
        epsg = 32600 + zone if lat >= 0 else 32700 + zone

        # Test if this EPSG is valid
        _ = gpd.GeoSeries([Point(0, 0)], crs=4326).to_crs(epsg=epsg)
        return gpd.CRS.from_epsg(epsg)

    except Exception:
        # Fallback to Web Mercator (EPSG:3857)
        print("Warning: Could not auto-detect local UTM zone. Falling back to EPSG:3857.")
        return gpd.CRS.from_epsg(3857)


def weighted_gini(values: np.ndarray, weights: np.ndarray) -> float:
    """
    Calculates the weighted Gini coefficient ([0,1]).

    A fast, vectorized, and robust O(n log n) implementation.
    Assumes values >= 0 and weights >= 0.
    """
    # Ensure inputs are numpy arrays and filter out NaNs/invalid weights
    v = np.asarray(values, dtype=float)
    w = np.asarray(weights, dtype=float)
    mask = np.isfinite(v) & np.isfinite(w) & (w > 0)
    v, w = v[mask], w[mask]

    # Handle edge cases
    if v.size == 0:
        return np.nan

    weighted_values = w * v
    total_weighted_value = weighted_values.sum()

    # If all values are the same, or total value is zero, Gini is 0
    if total_weighted_value <= 0 or np.allclose(v, v[0]):
        return 0.0

    # Sort by value (this is the O(n log n) step)
    order = np.argsort(v)
    v, w, weighted_values = v[order], w[order], weighted_values[order]

    # Calculate cumulative sums
    total_weight = w.sum()
    cum_weights_norm = np.cumsum(w) / total_weight
    cum_weighted_values_norm = np.cumsum(weighted_values) / total_weighted_value

    # Get Lorenz curve points
    P_prev = np.r_[0.0, cum_weights_norm[:-1]]
    L_prev = np.r_[0.0, cum_weighted_values_norm[:-1]]

    # Area under the Lorenz curve (using trapezoidal rule)
    # area = sum( (x_i - x_i-1) * (y_i + y_i-1) / 2 )
    # This code calculates (2 * Area) for efficiency.
    area_x2 = np.sum((cum_weights_norm - P_prev) * (cum_weighted_values_norm + L_prev))

    # Gini = 1 - 2 * (Area under Lorenz Curve)
    G = 1.0 - area_x2
    return float(np.clip(G, 0.0, 1.0))


def main():
    print(f"Starting fairness analysis for: {CITY_NAME}")

    # --- 1) Load Data ---
    print("Loading input files...")
    if not os.path.exists(LOGISTICS_CSV_PATH):
        raise FileNotFoundError(f"Logistics stations file not found: {LOGISTICS_CSV_PATH}")
    if not os.path.exists(GRID_SHP_PATH):
        raise FileNotFoundError(f"Population grid file not found: {GRID_SHP_PATH}")
    if not os.path.exists(DISTRICT_SHP_PATH):
        raise FileNotFoundError(f"District boundaries file not found: {DISTRICT_SHP_PATH}")

    logistics_df = pd.read_csv(LOGISTICS_CSV_PATH)
    # Accommodate 'log' or 'lon' as the longitude column
    lon_col = "log" if "log" in logistics_df.columns else "lon"
    if lon_col not in logistics_df.columns or "lat" not in logistics_df.columns:
        raise ValueError(f"Stations CSV must have 'lat' and either 'log' or 'lon' columns.")

    grid = gpd.read_file(GRID_SHP_PATH)
    counties = gpd.read_file(DISTRICT_SHP_PATH)

    # --- 2) Standardize to Metric CRS ---
    print("Standardizing coordinate reference systems (CRS)...")
    metric_crs = auto_select_metric_crs(grid)
    print(f"Using metric CRS: {metric_crs.to_string()}")
    grid_m = grid.to_crs(metric_crs)
    counties_m = counties.to_crs(metric_crs)

    # --- 3) Logistics Stations -> GeoDataFrame (WGS84 -> Metric) ---
    logi_gdf = gpd.GeoDataFrame(
        logistics_df.copy(),
        geometry=gpd.points_from_xy(logistics_df[lon_col].astype(float), logistics_df["lat"].astype(float)),
        crs=4326  # Assume input CSV is WGS84
    ).to_crs(metric_crs)

    if len(logi_gdf) == 0:
        raise RuntimeError("Logistics stations file is empty.")

    # --- 4) Calculate Nearest Station Distance (once, for all 24 hours) ---
    print("Calculating nearest station distance for each grid cell...")

    # Use representative_point() for robust centroid-like points
    reps = grid_m.geometry.representative_point()
    grid_xy = np.column_stack([reps.x.values, reps.y.values]).astype(float)

    logi_xy = np.column_stack([logi_gdf.geometry.x.values, logi_gdf.geometry.y.values]).astype(float)

    # Build k-d tree for efficient nearest neighbor search
    tree = cKDTree(logi_xy)
    distances, _ = tree.query(grid_xy)

    # Apply distance floor to avoid divide-by-zero
    distances = np.maximum(distances, float(DISTANCE_FLOOR_METERS))

    assert len(distances) == len(grid_m), "Distances array must match grid length"

    # --- 5) Assign Unique District to Each Grid Cell ---
    #    Uses a 'within' join on the grid's representative points
    #    to avoid double-counting grids that span district boundaries.

    # 5.1) Auto-detect district name field
    print("Assigning grid cells to districts...")
    name_field = None
    cand_lower = [c.lower() for c in DISTRICT_NAME_FIELD_CANDIDATES]
    for fld in counties_m.columns:
        if counties_m[fld].dtype == object and fld.lower() in cand_lower:
            name_field = fld
            break

    if name_field is None:
        # Fallback: find the first string (object) column
        str_cols = [c for c in counties_m.columns if counties_m[c].dtype == object]
        if not str_cols:
            raise ValueError(f"Could not find a district name field in {DISTRICT_SHP_PATH}.")
        name_field = str_cols[0]
    print(f"Using district name field: '{name_field}'")

    # 5.2) Spatial join: grid points 'within' county polygons
    grid_pts = gpd.GeoDataFrame(
        pd.DataFrame(index=grid_m.index),  # Maintain the exact index as grid_m
        geometry=reps,
        crs=grid_m.crs
    )
    join = gpd.sjoin(
        grid_pts,
        counties_m[[name_field, "geometry"]],
        how="left",
        predicate="within"
    ).rename(columns={name_field: "District"})[["District"]]

    # 5.3) Align results and assign back to grid_m
    # Use groupby().first() to ensure one district per grid index
    district_series = join["District"].groupby(join.index).first()
    district_series = district_series.reindex(grid_m.index)  # Re-align to full grid
    district_series = district_series.fillna("Unknown")  # Assign 'Unknown' to cells outside all districts
    grid_m["District"] = district_series.values

    # --- 6) Find Population Columns (value_00...value_23) ---
    pop_cols = [c for c in grid_m.columns if str(c).lower().startswith("value_")]
    if not pop_cols:
        raise ValueError("No population columns (e.g., 'value_00') found in grid Shapefile.")
    print(f"Found {len(pop_cols)} hourly population columns to analyze.")

    # --- 7) Calculate Fairness (Gini) by District, by Hour ---
    records = []
    print("Calculating hourly Gini by district...")

    for col in sorted(pop_cols):
        # 'w' = weights (population)
        w = pd.to_numeric(grid_m[col], errors="coerce").to_numpy(float)
        w[np.isnan(w) | (w < 0)] = 0.0  # Clean invalid data

        # 'v' = values (accessibility ratio = population / distance)
        # We use the *same* distance for all 24 hours.
        v = np.divide(w, distances, out=np.zeros_like(w), where=distances > 0)

        # Create a temporary DataFrame for easy groupby
        df_tmp = pd.DataFrame({
            "District": grid_m["District"].to_numpy(object),
            "v": v, "w": w, "dist": distances
        })

        # Calculate Gini for each district
        for district, sub_df in df_tmp.groupby("District"):
            pop_weights = sub_df["w"].to_numpy(float)
            pop_sum = pop_weights.sum()

            if pop_sum <= 0:
                # No population, Gini is undefined (NaN)
                gini = np.nan
                mean_dist = np.nan
                mean_ratio = np.nan
            else:
                access_values = sub_df["v"].to_numpy(float)
                gini = weighted_gini(access_values, pop_weights)

                # Calculate weighted mean distance and ratio for context
                dist_values = sub_df["dist"].to_numpy(float)
                mean_dist = float(np.average(dist_values, weights=pop_weights))
                mean_ratio = float(np.average(access_values, weights=pop_weights))

            records.append({
                "City": CITY_NAME,
                "District": district,
                "Population_col": col,
                "Pop_sum": float(pop_sum),
                "Mean_distance_m": mean_dist,
                "Mean_ratio": mean_ratio,
                "Fairness_Gini": gini
            })

    # --- 8) Save Results ---
    out_df = pd.DataFrame(records).sort_values(["District", "Population_col"])

    # Ensure output directory exists
    os.makedirs(os.path.dirname(OUTPUT_CSV_PATH), exist_ok=True)
    out_df.to_csv(OUTPUT_CSV_PATH, index=False, encoding="utf-8-sig")

    print("\n" + "=" * 30)
    print(f"Analysis complete. Output saved to:\n{OUTPUT_CSV_PATH}")
    print("Note: 'Fairness_Gini' is [0, 1]. Lower is more equitable.")
    print("=" * 30)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"[ERROR] {e}", file=sys.stderr)
        sys.exit(1)