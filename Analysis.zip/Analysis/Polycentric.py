#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Batch polycentric metrics for multiple cities + per-center export (lon/lat).

Overview:
- Reads a city list CSV (must have a 'City' or 'city' column).
- For each city, reads a population grid: Data/City/{City}/mesh/mesh_{lowercity}.shp
- Performs clustering (GMM or KMeans) for K=1..Kmax.
- Calculates dispersion, polycentric structure, and other metrics.
- Includes compatibility for older sklearn versions (uses weighted resampling
  if 'sample_weight' is not supported by the model).
- Exports:
  1) Metrics table per city per K, and a combined summary table.
  2) Detailed center coordinates (lon/lat EPSG:4326) and radii for each K.
  3) Detailed centers for the "optimal K" for each city, and a combined summary.

Usage Example:
python polycentric_metrics_batch.py \
  --citylist citylist.csv \
  --outdir output/poly_all \
  --kmax 8 --method gmm \
  --popcols value_00 \
  --force_epsg 3857 \
  --save_per_city
"""

import os
import re
import argparse
import warnings
import inspect
import numpy as np
import pandas as pd
import geopandas as gpd
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
from sklearn.metrics import silhouette_score

# Use Agg backend for non-interactive server environments
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore", category=UserWarning)


# ----------------- Basic Utilities -----------------

def ensure_outdir(directory):
    """Ensures an output directory exists."""
    os.makedirs(directory, exist_ok=True)
    return directory


def to_metric_crs(gdf, force_epsg=None):
    """
    Projects a GeoDataFrame to a metric CRS (for distance/radius calculations).
    - If already metric, returns as is.
    - If no CRS is defined, 'force_epsg' can be used to assign one.
    - Defaults to EPSG:3857 (Web Mercator) if projection is needed.
    """
    if gdf.crs is None and force_epsg is not None:
        gdf = gdf.set_crs(epsg=int(force_epsg))
    if gdf.crs is None:
        gdf = gdf.set_crs("EPSG:4326", allow_override=True)

    try:
        # Check if the CRS is already projected and uses meters
        if gdf.crs.is_projected and any(
                a.unit_name.lower().startswith("met") for a in gdf.crs.axis_info
        ):
            return gdf
    except Exception:
        pass  # Fallback to reprojection

    return gdf.to_crs(epsg=3857)


def weighted_centroid(X, w):
    """Calculates the weighted centroid (center of mass) of points X."""
    wsum = w.sum()
    return (X * w.reshape(-1, 1)).sum(axis=0) / max(wsum, 1e-12)


def pairwise_mean_distance(C):
    """Calculates the mean pairwise distance between all points in C."""
    m = len(C)
    if m <= 1:
        return 0.0
    dsum = 0.0
    cnt = 0
    for i in range(m):
        for j in range(i + 1, m):
            dsum += np.linalg.norm(C[i] - C[j])
            cnt += 1
    return float(dsum / cnt)


def sqrt_areaN_by_cluster(areas, weights, labels, K):
    """Calculates Σ_clusters sqrt(A_j * N_j) as a proxy for intra-cluster scale."""
    s = 0.0
    for j in range(K):
        m = (labels == j)
        Aj = float(areas[m].sum())
        Nj = float(weights[m].sum())
        if Aj > 0 and Nj > 0:
            s += np.sqrt(Aj * Nj)
    return s


def area_series(gdf):
    """Safely extracts the area of each geometry."""
    try:
        return gdf.geometry.area.values.astype(float)
    except Exception:
        return np.zeros(len(gdf), dtype=float)


def detect_popcols(gdf, prefix="value_"):
    """Detects population columns matching a prefix (e.g., 'value_00')."""
    pat = re.compile(rf"^{re.escape(prefix)}\d{{2}}$")
    return [c for c in gdf.columns if pat.match(c)]


def _has_arg_with_name(func, name):
    """Checks if a function's signature contains an argument by name."""
    try:
        return name in inspect.signature(func).parameters
    except Exception:
        return False


def weighted_resample(X, w, n_samples=20000, rng=None):
    """
    Approximates weighted clustering by weighted resampling.
    Used as a fallback for sklearn models that don't support 'sample_weight'.
    """
    rng = np.random.default_rng(42) if rng is None else rng
    p = w / max(w.sum(), 1e-12)
    n_samples = int(min(max(2000, n_samples), 100000))
    idx = rng.choice(len(X), size=n_samples, replace=True, p=p)
    return X[idx]


# ----------------- Clustering Wrappers (Weight-Compatible) -----------------

def gmm_fit_predict_weighted(X, w, K, random_state=42):
    """Fits a GMM, using 'sample_weight' if available, or resampling if not."""
    gm = GaussianMixture(n_components=K, covariance_type="full",
                         random_state=random_state, reg_covar=1e-6)

    if _has_arg_with_name(gm.fit, "sample_weight"):
        # Modern sklearn: use sample_weight directly
        gm.fit(X, sample_weight=w)
    else:
        # Older sklearn: use weighted resampling as an approximation
        Xr = weighted_resample(X, w, n_samples=min(20000, 20 * K),
                               rng=np.random.default_rng(random_state))
        gm.fit(Xr)

    labels = gm.predict(X)
    centers = gm.means_
    bic = float(gm.bic(X))
    return gm, labels, centers, bic


def kmeans_fit_predict_weighted(X, w, K, random_state=42):
    """Fits KMeans, using 'sample_weight' if available, or resampling if not."""
    km = KMeans(n_clusters=K, n_init=10, random_state=random_state)

    if _has_arg_with_name(km.fit, "sample_weight"):
        # Modern sklearn
        labels = km.fit_predict(X, sample_weight=w)
    else:
        # Older sklearn: approximate with weighted resampling
        Xr = weighted_resample(X, w, n_samples=min(20000, 20 * K),
                               rng=np.random.default_rng(random_state))
        km.fit(Xr)
        labels = km.predict(X)

    centers = km.cluster_centers_
    return km, labels, centers


# ----------------- Morphology Metrics Utilities -----------------

def rank_size_slope_from_weights(wj, maxM=4):
    """
    Calculates the Rank-Size slope (after Meijers & Burger).
    Averages the log(size) ~ log(rank) linear fit slope for the top 2..maxM centers.
    Returns (beta_avg, steepness), where steepness = -beta_avg.
    A larger 'steepness' value indicates a more monocentric structure.
    """
    sizes = np.asarray(wj, dtype=float)
    sizes = np.sort(sizes)[::-1]
    K = len(sizes)
    slopes = []

    for m in range(2, int(min(K, maxM)) + 1):
        ranks = np.arange(1, m + 1, dtype=float)
        x = np.log(ranks)
        y = np.log(np.maximum(sizes[:m], 1e-12))
        slope, _ = np.polyfit(x, y, 1)
        slopes.append(float(slope))

    if len(slopes) == 0:
        return np.nan, np.nan

    beta_avg = float(np.mean(slopes))
    steepness = float(-beta_avg)
    return beta_avg, steepness


def _smooth_indicator(x, tau, kappa=0.2):
    """
    Smooths a hard threshold (x >= tau) into a continuous [0,1] weight
    using a logistic function. Kappa controls the transition width.
    """
    tau = float(tau)
    s = (np.asarray(x, dtype=float) - tau) / max(kappa * tau + 1e-12, 1e-12)
    return 1.0 / (1.0 + np.exp(-s))


def dispersion_from_weights(
        wj,
        min_center_pop=25000.0,
        min_center_share=0.10,
        soft_kappa=0.20,
        topN=4,
        topN_frac=0.5
):
    """
    Calculates dispersion metrics based on population shares outside 'large' centers.

    Returns a dict with different definitions of "outside":
    - outside_large_hard: Share outside centers meeting a hard threshold.
    - outside_large_soft: Share outside centers, using a smooth (logistic) threshold (Recommended).
    - outside_topN: Share outside the fixed Top-N centers.
    - outside_topN_frac: Share outside the Top-⌈frac*K⌉ centers (Recommended fallback).
    """
    wj = np.asarray(wj, dtype=float)
    total = float(np.sum(wj))
    if not np.isfinite(total) or total <= 0:
        return dict(
            outside_large_hard=np.nan,
            outside_large_soft=np.nan,
            outside_topN=np.nan,
            outside_topN_frac=np.nan
        )

    # Adaptive threshold: max of absolute (e.g., 25k) and relative (e.g., 10%)
    T_abs = float(min_center_pop)
    T_share = float(min_center_share) * total
    T = max(T_abs, T_share)

    # Hard threshold
    share_in_large_hard = float(np.sum(wj[wj >= T]) / total)
    outside_large_hard = float(1.0 - share_in_large_hard)

    # Soft (logistic) threshold
    alpha = _smooth_indicator(wj, tau=T, kappa=soft_kappa)
    share_in_large_soft = float(np.sum(wj * alpha) / total)
    outside_large_soft = float(1.0 - share_in_large_soft)

    # Fixed Top-N
    N_fixed = int(max(1, min(int(topN), len(wj))))
    share_in_topN = float(np.sum(np.sort(wj)[::-1][:N_fixed]) / total)
    outside_topN = float(1.0 - share_in_topN)

    # Proportional Top-N (Top-N_frac*K)
    N_frac = int(max(1, np.ceil(float(topN_frac) * len(wj))))
    share_in_topN_frac = float(np.sum(np.sort(wj)[::-1][:N_frac]) / total)
    outside_topN_frac = float(1.0 - share_in_topN_frac)

    return dict(
        outside_large_hard=outside_large_hard,
        outside_large_soft=outside_large_soft,
        outside_topN=outside_topN,
        outside_topN_frac=outside_topN_frac
    )


def normalized_entropy_from_shares(s):
    """
    Calculates normalized entropy [0,1]. Higher = more balanced/dispersed.
    This is continuous and independent of thresholds or Top-N choices.
    """
    s = np.asarray(s, dtype=float)
    s = s[(s > 0) & np.isfinite(s)]
    K = len(s)
    if K <= 1:
        return np.nan  # Entropy is undefined for 1 item
    # H / H_max = H / log(K)
    Hs = -np.sum(s * np.log(s + 1e-12)) / np.log(K)
    return float(Hs)


# ----------------- Metrics Calculation -----------------
def compute_metrics_for_K(
        X, w, cell_areas, labels, centers,
        morph_min_center_pop=25000.0,
        morph_min_center_share=0.10,
        morph_soft_kappa=0.20,
        morph_ranksize_maxM=4,
        morph_topN=4,
        morph_topN_frac=0.50
):
    """
    Computes all polycentric metrics for a given clustering result (K).
    """
    # Weighted gyration radius
    mu = weighted_centroid(X, w)
    Rg = np.sqrt(((w * (np.linalg.norm(X - mu, axis=1) ** 2)).sum()) / max(w.sum(), 1e-12))

    # Weighted mean distance to nearest center
    dmin = np.min(np.linalg.norm(X[:, None, :] - centers[None, :, :], axis=2), axis=1)
    S_disp = float((w * dmin).sum() / max(w.sum(), 1e-12))

    # Cluster population weights, Herfindahl index (H), and Effective N (N_eff)
    K = len(centers)
    wj = np.array([w[labels == j].sum() for j in range(K)], dtype=float)
    s = wj / max(w.sum(), 1e-12)  # Population shares
    H = float((s ** 2).sum()) if K > 0 else np.nan
    N_eff = (1.0 / H) if H > 0 else np.nan

    # Morphological Dispersion (multiple definitions)
    disp = dispersion_from_weights(
        wj,
        min_center_pop=morph_min_center_pop,
        min_center_share=morph_min_center_share,
        soft_kappa=morph_soft_kappa,
        topN=morph_topN,
        topN_frac=morph_topN_frac
    )
    morph_disp_outside_large_hard = disp["outside_large_hard"]
    morph_disp_outside_large_soft = disp["outside_large_soft"]  # Recommended
    morph_disp_outside_topN = disp["outside_topN"]
    morph_disp_outside_topN_frac = disp["outside_topN_frac"]

    # Mean pairwise distance between centers
    D_centers = pairwise_mean_distance(centers)

    # Intra-cluster scale proxy: Σ sqrt(Area_j * Pop_j)
    S_intra = sqrt_areaN_by_cluster(cell_areas, w, labels, K)

    # Mean distance from other centers to the *largest* (by pop) center
    if K <= 1:
        D_to_largest_center_mean = 0.0
    else:
        j_star = int(np.argmax(wj))
        d_to_star = np.linalg.norm(centers - centers[j_star], axis=1)
        D_to_largest_center_mean = float(np.mean(np.delete(d_to_star, j_star))) if len(d_to_star) > 1 else 0.0

    # Morphological Centrality (Rank-Size slope)
    beta_avg, steepness = rank_size_slope_from_weights(wj, maxM=morph_ranksize_maxM)

    # Continuous Dispersion (Normalized Entropy)
    morph_disp_entropy = normalized_entropy_from_shares(s)

    return dict(
        K=K,
        R_g=Rg,
        S_disp=S_disp,
        H=H,
        N_eff=N_eff,
        D_centers=D_centers,
        intra_proxy_SqrtAN=S_intra,
        D_to_largest_center_mean=D_to_largest_center_mean,
        # Morphological Centrality (higher = more monocentric)
        morph_ranksize_beta_avg=beta_avg,  # Negative value, steeper = more monocentric
        morph_centrality_steepness=steepness,  # Positive value, higher = more monocentric
        # Morphological Dispersion (higher = more dispersed)
        morph_dispersion_outside_large_centers_hard=morph_disp_outside_large_hard,
        morph_dispersion_outside_large_centers=morph_disp_outside_large_soft,  # Recommended
        morph_dispersion_outside_topN=morph_disp_outside_topN,
        morph_dispersion_outside_topN_frac=morph_disp_outside_topN_frac,
        morph_dispersion_entropy=morph_disp_entropy
    )


# ----------------- Center Coordinate Conversion -----------------
def centers_xy_to_lonlat(centers, src_crs):
    """Converts center (x, y) coordinates from metric CRS to lon/lat (EPSG:4326)."""
    if centers is None or len(centers) == 0:
        return np.array([]), np.array([])
    gdfc = gpd.GeoDataFrame(geometry=gpd.points_from_xy(centers[:, 0], centers[:, 1]), crs=src_crs)
    gdfc_ll = gdfc.to_crs(epsg=4326)
    lon = gdfc_ll.geometry.x.values.astype(float)
    lat = gdfc_ll.geometry.y.values.astype(float)
    return lon, lat


# ----------------- Center Summary Statistics -----------------
def weighted_quantile(values, weights, q):
    """Computes the weighted quantile (q ∈ [0,1])."""
    v = np.asarray(values, dtype=float)
    w = np.asarray(weights, dtype=float)
    if len(v) == 0 or w.sum() <= 0:
        return np.nan
    order = np.argsort(v)
    v, w = v[order], w[order]
    cw = np.cumsum(w)
    cutoff = q * w.sum()
    idx = np.searchsorted(cw, cutoff, side="left")
    idx = min(idx, len(v) - 1)
    return float(v[idx])


def summarize_centers(X, w, labels, centers, areas, city, K, src_crs):
    """
    Generates a per-center summary (lon/lat, radius metrics, pop, area).
    Radius stats are calculated in metric space; output coords are lon/lat.
    """
    rows = []
    w_total = w.sum()
    centers = np.asarray(centers, dtype=float)
    # Get lon/lat for all centers
    lon, lat = centers_xy_to_lonlat(centers, src_crs)

    for j in range(len(centers)):
        m = (labels == j)
        if not np.any(m):
            continue

        # Distances (meters) from cells to this center
        d = np.linalg.norm(X[m] - centers[j], axis=1)
        wj = w[m]  # Weights for cells in this cluster
        Aj = float(areas[m].sum())
        wsum = float(wj.sum())

        # Weighted radius statistics
        r_mean = float((d * wj).sum() / max(wsum, 1e-12))
        r_p50 = weighted_quantile(d, wj, 0.50)
        r_p90 = weighted_quantile(d, wj, 0.90)
        r_max = float(np.max(d)) if len(d) else np.nan

        rows.append(dict(
            City=city, K=int(K), center_id=int(j + 1),
            center_lon=float(lon[j]) if len(lon) > j else np.nan,
            center_lat=float(lat[j]) if len(lat) > j else np.nan,
            center_x=float(centers[j][0]),  # Metric X
            center_y=float(centers[j][1]),  # Metric Y
            r_mean_w=r_mean, r_p50=r_p50, r_p90=r_p90, r_max=r_max,
            N_cluster=wsum, A_cluster=Aj,
            pop_share=float(wsum / max(w_total, 1e-12)),
            n_cells=int(m.sum())
        ))
    return rows


# ----------------- Single City Processor -----------------
def process_city(city, outdir_city, popcols=None, kmax=8, method="gmm",
                 force_epsg=None, save_figs=False, random_state=42,
                 morph_min_center_pop=25000.0,
                 morph_min_center_share=0.10,
                 morph_soft_kappa=0.20,
                 morph_ranksize_maxM=4,
                 morph_topN=4,
                 morph_topN_frac=0.50):
    """
    Runs the full polycentric analysis for a single city.
    """
    lowercity = city.lower()
    grid_path = os.path.join("Data", "City", city, "mesh", f"mesh_{lowercity}.shp")

    if not os.path.exists(grid_path):
        return None, f"[SKIP] {city}: Grid not found at {grid_path}"

    try:
        gdf = gpd.read_file(grid_path)
        gdf = to_metric_crs(gdf, force_epsg=force_epsg)
        crs_metric = gdf.crs  # Store the metric CRS for later

        # --- 1. Get Population Weights (w) ---
        if popcols is None or len(popcols) == 0:
            # Auto-detect 'value_XX' columns and sum them
            auto_cols = detect_popcols(gdf, prefix="value_")
            if len(auto_cols) == 0:
                return None, f"[SKIP] {city}: No population columns detected (e.g., value_00)"
            use_cols = auto_cols
        else:
            # Use specified population columns
            use_cols = popcols
            for c in use_cols:
                if c not in gdf.columns:
                    return None, f"[SKIP] {city}: Missing specified pop column {c}"

        w = gdf[use_cols].sum(axis=1).values.astype(float)
        w[w < 0] = 0.0

        # --- 2. Get Coordinates (X) and Areas (A) ---
        reps = gdf.geometry.representative_point()
        X = np.vstack([reps.x.values, reps.y.values]).T.astype(float)
        A = area_series(gdf)

        # --- 3. Filter to valid data ---
        mask = (w > 0) & np.isfinite(X).all(axis=1)
        X, w, A = X[mask], w[mask], A[mask]

        if len(X) < max(3, kmax + 1):
            return None, f"[SKIP] {city}: Too few cells with positive population ({len(X)})"

        rows_metrics = []
        rows_centers_allK = []
        ensure_outdir(outdir_city)

        # --- 4. Loop K=1..kmax and run clustering ---
        if method.lower() == "gmm":
            crit = []
            for K in range(1, int(kmax) + 1):
                gm, labels, centers, bic = gmm_fit_predict_weighted(X, w, K, random_state=random_state)

                metr = compute_metrics_for_K(
                    X, w, A, labels, centers,
                    morph_min_center_pop=morph_min_center_pop,
                    morph_min_center_share=morph_min_center_share,
                    morph_soft_kappa=morph_soft_kappa,
                    morph_ranksize_maxM=morph_ranksize_maxM,
                    morph_topN=morph_topN,
                    morph_topN_frac=morph_topN_frac
                )
                metr.update(dict(BIC=bic))
                metr["City"] = city
                rows_metrics.append(metr)
                crit.append((K, bic))

                # Get detailed summary for these centers (with lon/lat)
                rows_centers_allK += summarize_centers(X, w, labels, centers, A, city, K, crs_metric)

            crit = pd.DataFrame(crit, columns=["K", "BIC"]).sort_values("K")
            Kstar = int(crit.loc[crit["BIC"].idxmin(), "K"])  # Optimal K = min BIC

            if save_figs:
                plt.figure(figsize=(6, 4))
                plt.plot(crit["K"], crit["BIC"], marker="o")
                plt.xlabel("Number of components (K)")
                plt.ylabel("BIC (lower is better)")
                plt.title(f"{city}: GMM Model Selection (BIC)")
                plt.axvline(Kstar, ls="--", color="red", label=f"Optimal K={Kstar}")
                plt.legend()
                plt.tight_layout()
                plt.savefig(os.path.join(outdir_city, f"{city}_BIC_curve.png"), dpi=200)
                plt.close()

        else:  # kmeans
            crit = []
            for K in range(1, int(kmax) + 1):
                km, labels, centers = kmeans_fit_predict_weighted(X, w, K, random_state=random_state)

                metr = compute_metrics_for_K(
                    X, w, A, labels, centers,
                    morph_min_center_pop=morph_min_center_pop,
                    morph_min_center_share=morph_min_center_share,
                    morph_soft_kappa=morph_soft_kappa,
                    morph_ranksize_maxM=morph_ranksize_maxM,
                    morph_topN=morph_topN,
                    morph_topN_frac=morph_topN_frac
                )
                metr["City"] = city

                if K == 1:
                    metr.update(dict(inertia=float(km.inertia_), silhouette=np.nan))
                    crit.append((K, -km.inertia_))  # Use -inertia for elbow
                else:
                    # Approx silhouette using a weighted sample
                    p = w / w.sum()
                    idx_size = min(5000, len(X))
                    idx = np.random.choice(len(X), size=idx_size, replace=False, p=p)
                    sil = float(silhouette_score(X[idx], labels[idx]))
                    metr.update(dict(inertia=float(km.inertia_), silhouette=sil))
                    crit.append((K, sil))

                rows_metrics.append(metr)
                rows_centers_allK += summarize_centers(X, w, labels, centers, A, city, K, crs_metric)

            crit = pd.DataFrame(crit, columns=["K", "score"]).sort_values("K")
            # Optimal K = max silhouette (K > 1)
            if (crit["K"] > 1).any():
                Kstar = int(crit.loc[crit[crit["K"] > 1]["score"].idxmax(), "K"])
            else:
                Kstar = 1

            if save_figs:
                fig, ax1 = plt.subplots(figsize=(6, 4))
                ax2 = ax1.twinx()
                ax1.plot(crit["K"], crit["score"], marker="o", color="blue", label="Silhouette")
                ax2.plot(crit["K"], [metr["inertia"] for metr in rows_metrics], marker="x", color="green",
                         label="Inertia")
                ax1.set_xlabel("Number of clusters (K)")
                ax1.set_ylabel("Silhouette Score (higher is better)", color="blue")
                ax2.set_ylabel("Inertia (lower is better)", color="green")
                ax1.set_title(f"{city}: KMeans Model Selection")
                ax1.axvline(Kstar, ls="--", color="red", label=f"Optimal K={Kstar}")
                fig.legend(loc="upper right", bbox_to_anchor=(0.9, 0.9))
                plt.tight_layout()
                plt.savefig(os.path.join(outdir_city, f"{city}_kmeans_selection.png"), dpi=200)
                plt.close()

        # --- 5. Compile and Save Results ---
        dfK = pd.DataFrame(rows_metrics).sort_values(["City", "K"])
        best_row = dfK[dfK["K"] == Kstar].copy()

        # Per-center details (all K and best K)
        centers_allK_df = pd.DataFrame(rows_centers_allK).sort_values(["City", "K", "center_id"])
        centers_best_df = centers_allK_df[centers_allK_df["K"] == Kstar].copy()

        # Save this city's individual files
        if outdir_city and os.path.isdir(outdir_city):
            try:
                dfK.to_csv(os.path.join(outdir_city, f"{city}_metrics_by_K.csv"),
                           index=False, encoding="utf-8-sig")
                best_row.to_csv(os.path.join(outdir_city, f"{city}_bestK_metrics.csv"),
                                index=False, encoding="utf-8-sig")
                centers_allK_df.to_csv(os.path.join(outdir_city, f"{city}_centers_by_K.csv"),
                                       index=False, encoding="utf-8-sig")
                centers_best_df.to_csv(os.path.join(outdir_city, f"{city}_bestK_centers.csv"),
                                       index=False, encoding="utf-8-sig")
            except Exception as e:
                print(f"[WARN] {city}: Failed to save individual city files: {e}")

        # Return all compiled DataFrames for batch aggregation
        return (dfK, best_row, centers_allK_df, centers_best_df), None

    except Exception as e:
        return None, f"[ERROR] {city}: {e}"


# ----------------- Batch Processor -----------------
def run_batch(citylist_csv, outdir, kmax=8, method="gmm", popcols_arg=None,
              force_epsg=None, save_per_city=False, random_state=42,
              morph_min_center_pop=25000.0, morph_min_center_share=0.10,
              morph_soft_kappa=0.20, morph_ranksize_maxM=4,
              morph_topN=4, morph_topN_frac=0.50):
    """
    Main batch processing function.
    """
    outdir = ensure_outdir(outdir)
    print(f"Starting batch processing. Output directory: {outdir}")

    # Read city list, try 'gbk' encoding first, fallback to 'utf-8-sig'
    try:
        cl = pd.read_csv(citylist_csv, encoding="gbk")
    except Exception:
        cl = pd.read_csv(citylist_csv, encoding="utf-8-sig")

    cname = None
    for cand in ["City", "city", "CITY", "Name", "name"]:
        if cand in cl.columns:
            cname = cand
            break
    if cname is None:
        raise ValueError("City list CSV must contain a 'City' (or 'city') column.")

    cities = cl[cname].astype(str).unique().tolist()
    print(f"Found {len(cities)} cities to process: {cities}")

    # Parse population columns argument
    popcols = None
    if popcols_arg:
        popcols = [c.strip() for c in popcols_arg.split(",") if c.strip()]
        print(f"Using specified population columns: {popcols}")
    else:
        print("No population columns specified. Will auto-detect 'value_XX' and sum them.")

    allK_tables = []
    best_tables = []
    centers_allK_list = []
    centers_best_list = []
    logs = []

    for city in cities:
        # Define output dir for this city's files
        out_city = os.path.join(outdir, city) if save_per_city else os.path.join(outdir, "_tmp")
        if save_per_city:
            ensure_outdir(out_city)

        print(f"\n--- Processing {city} (K=1..{kmax}, method={method}) ---")
        res, msg = process_city(
            city=city, outdir_city=out_city, popcols=popcols, kmax=kmax,
            method=method, force_epsg=force_epsg, save_figs=save_per_city,
            random_state=random_state,
            morph_min_center_pop=morph_min_center_pop,
            morph_min_center_share=morph_min_center_share,
            morph_soft_kappa=morph_soft_kappa,
            morph_ranksize_maxM=morph_ranksize_maxM,
            morph_topN=morph_topN,
            morph_topN_frac=morph_topN_frac
        )

        if msg:
            print(msg)  # Print skip/error message
            logs.append(dict(City=city, msg=msg))
            continue

        # Unpack results and append to summary lists
        dfK, best_row, centers_allK_df, centers_best_df = res
        allK_tables.append(dfK)
        best_tables.append(best_row.assign(City=city))
        centers_allK_list.append(centers_allK_df)
        centers_best_list.append(centers_best_df)
        print(f"--- Finished {city} ---")

    # --- 7. Aggregate and Save Batch Results ---
    print("\nAggregating batch results...")

    if len(allK_tables):
        allK_df = pd.concat(allK_tables, ignore_index=True)
        allK_df.to_csv(os.path.join(outdir, "all_cities_metrics_by_K.csv"),
                       index=False, encoding="utf-8-sig")
        print(f"Saved: all_cities_metrics_by_K.csv ({len(allK_df)} rows)")
    else:
        allK_df = pd.DataFrame()

    if len(best_tables):
        best_df = pd.concat(best_tables, ignore_index=True)
        # Ensure one "best" row per city
        best_df = best_df.sort_values(["City", "K"]).drop_duplicates(subset=["City"], keep="first")
        best_df.to_csv(os.path.join(outdir, "all_cities_bestK_metrics.csv"),
                       index=False, encoding="utf-8-sig")
        print(f"Saved: all_cities_bestK_metrics.csv ({len(best_df)} rows)")
    else:
        best_df = pd.DataFrame()

    # Center-level details (with lon/lat coordinates)
    if len(centers_allK_list):
        centers_allK = pd.concat(centers_allK_list, ignore_index=True)
        centers_allK.to_csv(os.path.join(outdir, "all_cities_centers_by_K.csv"),
                            index=False, encoding="utf-8-sig")
        print(f"Saved: all_cities_centers_by_K.csv ({len(centers_allK)} rows)")
    else:
        centers_allK = pd.DataFrame()

    if len(centers_best_list):
        centers_best = pd.concat(centers_best_list, ignore_index=True)
        centers_best = centers_best.sort_values(["City", "K", "center_id"])
        centers_best.to_csv(os.path.join(outdir, "all_cities_bestK_centers.csv"),
                            index=False, encoding="utf-8-sig")
        print(f"Saved: all_cities_bestK_centers.csv ({len(centers_best)} rows)")
    else:
        centers_best = pd.DataFrame()

    if len(logs):
        pd.DataFrame(logs).to_csv(os.path.join(outdir, "batch_logs.csv"),
                                  index=False, encoding="utf-8-sig")
        print(f"Saved: batch_logs.csv ({len(logs)} entries)")

    print(f"\n[DONE] Batch processing complete. Output directory: {outdir}")
    return allK_df, best_df


# ----------------- Command-Line Interface -----------------
def main():
    """Main function to parse arguments and run the batch process."""
    ap = argparse.ArgumentParser(
        description="Batch Polycentric Metrics for Multiple Cities.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    ap.add_argument("--citylist", required=True,
                    help="Path to the city list CSV (must contain 'City' or 'city' column)")
    ap.add_argument("--outdir", required=True,
                    help="Output directory for summary tables")
    ap.add_argument("--kmax", type=int, default=8,
                    help="Maximum number of clusters (K) to test")
    ap.add_argument("--method", choices=["gmm", "kmeans"], default="gmm",
                    help="Clustering method: GaussianMixture (gmm) or KMeans")
    ap.add_argument("--popcols", type=str, default=None,
                    help="Population columns (comma-separated). If None, auto-detects 'value_XX' and sums them.")
    ap.add_argument("--force_epsg", type=int, default=None,
                    help="Force assign this EPSG code if grid CRS is missing (e.g., 3857)")
    ap.add_argument("--save_per_city", action="store_true",
                    help="Save individual CSVs and plots for each city")

    # --- Morphology Parameter Group ---
    morph_group = ap.add_argument_group('Morphology Parameters')
    morph_group.add_argument("--morph_min_center_pop", type=float, default=25000,
                             help="Absolute population threshold for a 'large center'")
    morph_group.add_argument("--morph_min_center_share", type=float, default=0.10,
                             help="Relative population threshold for a 'large center' (share of city total)")
    morph_group.add_argument("--morph_soft_kappa", type=float, default=0.20,
                             help="Logistic smoothing width (as fraction of threshold)")
    morph_group.add_argument("--morph_ranksize_maxM", type=int, default=4,
                             help="Rank-size slope uses avg of top 2..M centers (default: M=4)")
    morph_group.add_argument("--morph_topN", type=int, default=4,
                             help="Dispersion metric: share of pop outside fixed Top-N centers (default: N=4)")
    morph_group.add_argument("--morph_topN_frac", type=float, default=0.50,
                             help="Dispersion metric: share of pop outside Top-N*K centers (default: N=0.5)")

    args = ap.parse_args()

    run_batch(
        citylist_csv=args.citylist,
        outdir=args.outdir,
        kmax=args.kmax,
        method=args.method,
        popcols_arg=args.popcols,
        force_epsg=args.force_epsg,
        save_per_city=args.save_per_city,
        morph_min_center_pop=args.morph_min_center_pop,
        morph_min_center_share=args.morph_min_center_share,
        morph_soft_kappa=args.morph_soft_kappa,
        morph_ranksize_maxM=args.morph_ranksize_maxM,
        morph_topN=args.morph_topN,
        morph_topN_frac=args.morph_topN_frac
    )


if __name__ == "__main__":
    main()