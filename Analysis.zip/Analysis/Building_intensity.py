#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Batch processes building risk data for multiple cities.

This script reads a list of cities and an expansion factor from a CSV.
For each city, it:
1. Reads a building data file (Shapefile or DBF) using pyogrio.
2. Categorizes each building based on 'Density' and 'Hq' (height).
3. Scales 24 hourly 'risk_##' columns by the city's expansion factor
   and a normalization constant.
4. Aggregates the total scaled risk (sum) and building count for each
   combined category (Density + Hq).
5. Saves the resulting summary table to a CSV file in the city's folder.
"""

import os
import sys
import pandas as pd
from pyogrio import read_dataframe

# -----------------
# CONFIGURATION
# -----------------

# --- Input Files ---
# CSV file containing the list of cities and their factors
CSV_PATH = r"Data/CItyList.csv"
# Column name in CSV for the city name
CITY_COL = "City"
# Column name in CSV for the expansion/sampling factor
FACTOR_COL = "扩样系数"

# --- Path Templates ---
# Base directory for each city's building data
BUILDING_DIR = r"Data/City/{city}/Building"
# Input file name (can be .shp or .dbf as geometry is not read)
INPUT_FILE = "result.shp"
# Output file name for the statistics
OUTPUT_FILE = "Risk_By_Category.csv"

# --- Model Parameters ---
# Grid cell area in square meters (e.g., 500m * 500m)
# Used to calculate density: Iarea / GRID_AREA_SQM
GRID_AREA_SQM = 250000.0

# Normalization factor for risk (e.g., 500*500*10000)
RISK_NORMALIZATION_FACTOR = 2500000000.0

# --- Categorization Bins ---
# Building density (Iarea / GRID_AREA_SQM) categories
# Bins: [0, 0.01), [0.01, 0.1), [0.1, 0.2), [0.2, inf)
DENSITY_BINS = [0, 0.01, 0.1, 0.2, float("inf")]
DENSITY_LABELS = ["D1_[0-0.01)", "D2_[0.01-0.1)", "D3_[0.1-0.2)", "D4_[0.2-inf)"]

# Hq (height?) categories
# Bins: (-inf, 600), [600, 1500), [1500, inf)
HQ_BINS = [float("-inf"), 600, 1500, float("inf")]
HQ_LABELS = ["H1_<600", "H2_600-1500", "H3_>1500"]


# -----------------
# MAIN SCRIPT
# -----------------

def main():
    """
    Main function to run the batch processing.
    """
    # --- 1. Load City List ---
    try:
        # Try standard UTF-8 first
        city_df = pd.read_csv(CSV_PATH)
    except UnicodeDecodeError:
        try:
            # Fallback to GBK for Chinese Windows CSVs
            city_df = pd.read_csv(CSV_PATH, encoding="gbk")
        except Exception as e:
            print(f"Error: Could not read city list CSV at {CSV_PATH}.", file=sys.stderr)
            print(f"Details: {e}", file=sys.stderr)
            sys.exit(1)

    # Validate required columns
    if CITY_COL not in city_df.columns or FACTOR_COL not in city_df.columns:
        raise KeyError(
            f"Error: CSV must contain columns: '{CITY_COL}' and '{FACTOR_COL}'.\n"
            f"Found columns: {city_df.columns.tolist()}"
        )

    print(f"Starting batch processing for {len(city_df)} cities...")

    # --- 2. Loop Through Each City ---
    for _, row in city_df.iterrows():
        city = str(row[CITY_COL])
        try:
            factor = float(row[FACTOR_COL])
        except ValueError:
            print(f"[Warning] Invalid factor for {city}: '{row[FACTOR_COL]}'. Skipping.", file=sys.stderr)
            continue

        print(f"\n--- Processing {city} (Factor: {factor}) ---")

        # Use a try...except block to allow the batch to continue if one city fails
        try:
            # Define paths for this city
            city_path = BUILDING_DIR.format(city=city)
            input_path = os.path.join(city_path, INPUT_FILE)

            if not os.path.exists(input_path):
                print(f"[Warning] Input file not found: {input_path}. Skipping {city}.")
                continue

            # --- 3. Read Data ---
            print(f"  Reading data from {input_path}...")
            # Use pyogrio.read_dataframe for fast attribute-only reading
            df = read_dataframe(input_path, read_geometry=False)

            # --- 4. Validate Columns ---
            risk_cols = [f"risk_{i:02d}" for i in range(24)]
            needed_cols = ["Iarea", "Hq"] + risk_cols
            missing = [c for c in needed_cols if c not in df.columns]

            if missing:
                print(f"[Warning] {city} is missing required fields: {missing}. Skipping.")
                continue

            # --- 5. Categorize Data ---
            print("  Categorizing building data...")
            # Calculate density (Building_Intersect_Area / Grid_Area)
            df["Density"] = df["Iarea"] / GRID_AREA_SQM

            # Create categories using pd.cut (right=False means [bin_start, bin_end))
            df["DensityCat"] = pd.cut(df["Density"], bins=DENSITY_BINS, labels=DENSITY_LABELS, right=False)
            df["HqCat"] = pd.cut(df["Hq"], bins=HQ_BINS, labels=HQ_LABELS, right=False)

            # Create a combined category for grouping
            df["Combo"] = df["DensityCat"].astype(str) + "_" + df["HqCat"].astype(str)

            # --- 6. Scale Risk Values ---
            print("  Scaling risk values...")
            # Apply the expansion factor and normalization factor
            for rc in risk_cols:
                df[rc] = (df[rc] * factor) / RISK_NORMALIZATION_FACTOR

            # --- 7. Aggregate Data ---
            print("  Aggregating results...")

            # (1) Sum all 24 risk columns by the combo-category
            risk_summary = df.groupby("Combo")[risk_cols].sum()

            # (2) Count the number of buildings (rows) in each category
            count_summary = df.groupby("Combo").size().to_frame("Count")

            # (3) Join the two summaries
            summary = risk_summary.join(count_summary).reset_index()

            # --- 8. Save Output ---
            out_path = os.path.join(city_path, OUTPUT_FILE)
            summary.to_csv(out_path, index=False, encoding="utf-8-sig")
            print(f"[Success] {city} results saved to {out_path}")

        except Exception as e:
            # Log error for this city and continue to the next one
            print(f"[Error] Failed to process {city}. Error: {e}", file=sys.stderr)

    print("\nBatch processing finished.")


if __name__ == "__main__":
    main()