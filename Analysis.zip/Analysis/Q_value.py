import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import f


# -----------------
# 1. Optimal Discretization Function
# -----------------
def optidisc(formula: str, data: pd.DataFrame, discmethods: list, discitv: list) -> dict:
    """
    Performs optimal discretization of continuous explanatory variables
    based on the Geodetector q-statistic.

    This function iterates through different discretization methods and
    interval counts (strata) to find the combination that maximizes
    the q-value, which represents the explanatory power of the
    discretized variable on the response variable.

    Parameters:
    - formula: A string formula in the form 'response ~ explanatory1 + explanatory2'
    - data: A DataFrame containing the response and explanatory variables.
    - discmethods: A list of discretization methods to try (e.g., 'equal', 'quantile').
    - discitv: A list of interval counts (K) to try (e.g., [4, 5, 6]).

    Returns:
    - A dictionary where each key is an explanatory variable name.
      Each value is another dictionary containing the best method,
      interval count, q-value, and the resulting bins.
    """
    try:
        response_var, explanatory_str = formula.split('~')
    except ValueError:
        raise ValueError("Formula must be in the format 'response ~ explanatory1 + explanatory2'")

    response_var = response_var.strip()
    explanatory_vars = [v.strip() for v in explanatory_str.strip().split('+')]

    response = data[response_var]
    explanatory_df = data[explanatory_vars]

    # Store optimal discretization results
    opt_disc_results = {}

    for var in explanatory_df.columns:
        best_qv = -np.inf  # Initialize with negative infinity
        best_method = None
        best_n_intervals = None
        best_intervals = None

        # Matrix to store q-values for the heatmap
        qv_matrix = np.zeros((len(discitv), len(discmethods)))

        for j, method in enumerate(discmethods):
            for i, n_intervals in enumerate(discitv):

                # 1. Determine intervals based on the method
                try:
                    if method == 'equal':
                        # Equal interval width
                        intervals = np.linspace(explanatory_df[var].min(), explanatory_df[var].max(), n_intervals + 1)
                    elif method == 'quantile':
                        # Equal number of samples in each interval
                        intervals = np.percentile(explanatory_df[var], np.linspace(0, 100, n_intervals + 1))
                    elif method == 'geometric':
                        # Geometrically spaced intervals
                        intervals = np.geomspace(explanatory_df[var].min(), explanatory_df[var].max(), n_intervals + 1)
                    elif method == 'sd':
                        # Standard Deviation intervals
                        mean = explanatory_df[var].mean()
                        std = explanatory_df[var].std()
                        intervals = np.linspace(mean - 3 * std, mean + 3 * std, n_intervals + 1)
                    else:
                        raise ValueError(f"Unknown discretization method: {method}")
                except ValueError as e:
                    print(f"Warning: Could not create intervals for {var} (method={method}, k={n_intervals}). {e}")
                    qv_matrix[i, j] = np.nan
                    continue

                # 2. Discretize the variable using the calculated bins
                # 'include_lowest=True' ensures the minimum value is included
                discretized = pd.cut(explanatory_df[var], bins=intervals, include_lowest=True)

                # 3. Calculate Q-value using the factor detector
                qv = calculate_q_value(response, discretized)
                qv_matrix[i, j] = qv

                # 4. Track the best Q-value
                if qv > best_qv:
                    best_qv = qv
                    best_method = method
                    best_n_intervals = n_intervals
                    best_intervals = intervals

        # Store the best result for this variable
        opt_disc_results[var] = {
            'best_method': best_method,
            'best_n_intervals': best_n_intervals,
            'best_intervals': best_intervals,
            'best_qv': best_qv,
            'qv_matrix': qv_matrix
        }

    return opt_disc_results


# -----------------
# 2. Factor Detector (Q-statistic) Function
# -----------------
def calculate_q_value(response: pd.Series, discretized_var: pd.Series) -> float:
    """
    Calculates the Q-statistic (Factor Detector) from Geodetector.

    The Q-value measures the explanatory power of a stratified
    variable (discretized_var) on a continuous response variable.
    Q = 1 - (SSW / SST)
    where SSW is the Sum of Squares Within strata,
    and SST is the Total Sum of Squares.

    Parameters:
    - response: The response variable (e.g., NDVIchange).
    - discretized_var: The discretized explanatory variable (a pandas.Series
                       with categorical intervals).

    Returns:
    - Q-value as a float.
    """
    # Group the response by the discretized intervals
    grouped = response.groupby(discretized_var)

    # Total population (N)
    n = len(response)
    if n == 0:
        return 0.0

    # Calculate Total Sum of Squares (SST)
    # np.var(response) calculates variance as SST / N
    # Therefore, SST = np.var(response) * N
    ss_total = np.var(response) * n

    if ss_total == 0:
        return 1.0  # If total variance is zero, any factor explains 100%

    # Calculate Sum of Squares Within (SSW)
    # SSW = Σ(N_h * σ_h^2) where h is each stratum (interval)
    ss_within = 0.0
    for name, group in grouped:
        n_h = len(group)
        if n_h > 0:
            # np.var(group) is (SST_h / N_h)
            # (N_h * σ_h^2) is (N_h * SST_h / N_h) = SST_h
            ss_within += np.var(group) * n_h

    # Calculate Q-value
    # q = 1 - (SSW / SST)
    qv = 1 - (ss_within / ss_total)

    return qv


# -----------------
# 3. Visualization Function
# -----------------
def plot_optimal_discretization(opt_disc_results: dict, discmethods: list, discitv: list):
    """
    Plots a heatmap of Q-values for each variable's discretization results.

    Parameters:
    - opt_disc_results: The results dictionary from the optidisc function.
    - discmethods: The list of method names (for x-axis labels).
    - discitv: The list of interval counts (for y-axis labels).
    """
    for var, result in opt_disc_results.items():
        plt.figure(figsize=(10, 6))

        # Plot Q-values for each method and interval count
        sns.heatmap(result['qv_matrix'], annot=True, fmt='.4f', cmap='Blues',
                    xticklabels=discmethods,
                    yticklabels=discitv)

        plt.title(f"Optimal Discretization Q-values for {var}")
        plt.xlabel('Discretization Method')
        plt.ylabel('Number of Intervals (K)')
        plt.show()


# -----------------
# 4. Main Execution
# -----------------
def main():
    """
    Main function to run the example.
    """
    # 4.1. Example Data
    # Simulating a small dataset for illustration
    np.random.seed(42)
    data = pd.DataFrame({
        'NDVIchange':
            np.array([
                0.2740, 0.7050, 1.1662, 0.8932, 0.0969, 1.1674, 1.3065, 0.2172,
                0.6210, 0.3161, 0.4664, 0.4230, 1.1092, 0.5246, 0.8118, 0.6201,
                0.8521, 0.2428, 1.2885, 0.9998, 0.6111, 0.7013, 1.3896, 0.7568,
                1.6889, 1.5834, 0.4686, 0.8926, 0.3343, 0.3557, 0.6293, 0.3244,
                0.3242, 0.2310, 0.7474, 0.1809
            ]),
        'Tempchange': np.array([
            0.662423511, 0.687940321, 0.741913917, 0.721547298, 0.69593315,
            0.707621122, 0.713777839, 0.706353345, 0.663710214, 0.677378119,
            0.678003086, 0.706849819, 0.65033349, 0.812601144, 0.691578672,
            0.686192348, 0.715348551, 0.748284489, 0.745492274, 0.684793326,
            0.768723597, 0.705548306, 0.75840951, 0.641191581, 0.715164332,
            0.637900023, 0.669111356, 0.62301504, 0.763357228, 0.618537342,
            0.716356354, 0.683097896, 0.641601654, 0.715519331, 0.75821464,
            0.706609143
        ])
    })

    # 4.2. Example Call Parameters
    formula = 'NDVIchange ~ Tempchange'
    discmethods = ['equal', 'quantile', 'geometric']
    discitv = [4, 5, 6]

    # --- Perform optimal discretization ---
    print("Running optimal discretization...")
    opt_disc_results = optidisc(formula, data, discmethods, discitv)
    print("---" * 10)

    # --- Print optimal discretization results ---
    print("Optimal Discretization Results:")
    for var, result in opt_disc_results.items():
        print(f"Variable: {var}")
        print(f"  Best method: {result['best_method']}")
        print(f"  Best number of intervals: {result['best_n_intervals']}")
        print(f"  Best Q-value: {result['best_qv']:.6f}")
        print(f"  Best Intervals (bins): {result['best_intervals']}")
        print("-" * 20)

    # --- Plot optimal discretization results ---
    plot_optimal_discretization(opt_disc_results, discmethods, discitv)


if __name__ == "__main__":
    main()