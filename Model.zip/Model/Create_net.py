# -*- coding: utf-8 -*-
"""
Geospatial Network Preparation Script

This script processes CSV files containing coordinates for hubs and delivery nodes (DNs).
It converts them into GeoJSON format, then calculates the nearest hub for each
delivery node, generating a network of LineStrings representing these connections.

The final network is saved as both a GeoJSON file and an ESRI Shapefile.
"""

import pandas as pd
import geopandas as gpd
from shapely.geometry import LineString
import os

def convert_csv_to_gdf(csv_file, output_file, x_col='log', y_col='lat', crs_epsg=4326, save_geojson=True):
    """
    Converts a CSV file with coordinates to a GeoDataFrame and optionally saves
    it as a GeoJSON file.

    This function is more efficient than manual JSON creation as it uses
    pandas and geopandas directly.

    Args:
        csv_file (str): Path to the input CSV file.
        output_file (str): Path to save the output GeoJSON file.
        x_col (str): Column name for the longitude (or X coordinate).
        y_col (str): Column name for the latitude (or Y coordinate).
        crs_epsg (int): The EPSG code for the coordinate reference system (CRS).
                        Default is 4326 (WGS84).
        save_geojson (bool): If True, saves the file to `output_file`.

    Returns:
        gpd.GeoDataFrame: A GeoDataFrame containing the points.
    """
    try:
        # Read CSV data into a pandas DataFrame
        df = pd.read_csv(csv_file, encoding='utf-8-sig')

        # Check if coordinate columns exist
        if x_col not in df.columns or y_col not in df.columns:
            print(f"Error: Columns '{x_col}' or '{y_col}' not found in {csv_file}")
            return None

        # Convert pandas DataFrame to GeoDataFrame
        gdf = gpd.GeoDataFrame(
            df,
            geometry=gpd.points_from_xy(df[x_col], df[y_col]),
            crs=f"EPSG:{crs_epsg}"
        )

        # Save to GeoJSON file if requested
        if save_geojson:
            # Ensure the output directory exists
            os.makedirs(os.path.dirname(output_file), exist_ok=True)
            gdf.to_file(output_file, driver='GeoJSON')
            print(f"Successfully converted CSV to GeoDataFrame and saved to {output_file}")

        return gdf

    except Exception as e:
        print(f"Error during CSV to GeoJSON conversion: {e}")
        return None


def generate_delivery_connections(hubs_gdf, delivery_points_gdf, output_file):
    """
    Connects each delivery point to its nearest hub and calculates the distance.

    This function handles CRS (Coordinate Reference System) projection
    automatically to ensure distances are calculated in meters, not degrees.

    Args:
        hubs_gdf (gpd.GeoDataFrame): GeoDataFrame of hub points.
        delivery_points_gdf (gpd.GeoDataFrame): GeoDataFrame of delivery points.
        output_file (str): Path to save the resulting network (GeoJSON).

    Returns:
        gpd.GeoDataFrame: A GeoDataFrame of LineStrings connecting hubs
                          to delivery points, with calculated distances.
    """
    print("Generating delivery connections...")

    # --- CRS Handling for Accurate Distance Calculation ---
    # Ensure both GeoDataFrames use the same CRS
    if hubs_gdf.crs != delivery_points_gdf.crs:
        print("Warning: CRS mismatch. Re-projecting delivery points to match hubs.")
        delivery_points_gdf = delivery_points_gdf.to_crs(hubs_gdf.crs)

    # If the CRS is geographic (like WGS84, EPSG:4326), distances will be
    # in degrees. We must project to a UTM (or other projected) CRS
    # to calculate distances in meters.
    if hubs_gdf.crs.is_geographic:
        print(f"Input CRS is geographic ({hubs_gdf.crs}). Projecting to a suitable UTM CRS for distance calculation.")
        # Estimate a suitable projected CRS (e.g., a local UTM zone)
        projected_crs = hubs_gdf.estimate_utm_crs()
        hubs_proj = hubs_gdf.to_crs(projected_crs)
        delivery_proj = delivery_points_gdf.to_crs(projected_crs)
        print(f"Projected to {projected_crs} for calculations.")
    else:
        # CRS is already projected (e.g., UTM), no re-projection needed.
        print(f"Input CRS is already projected ({hubs_gdf.crs}). Distances will be in native units (e.g., meters).")
        hubs_proj = hubs_gdf
        delivery_proj = delivery_points_gdf

    # --- Find Nearest Hub and Create Connections ---
    connections = []
    for i, delivery_point in delivery_proj.iterrows():
        # Get the geometry of the current delivery point
        c_deliver = delivery_point.geometry

        # Find the index of the closest hub in the projected space
        closest_hub_idx = hubs_proj.geometry.distance(c_deliver).idxmin()
        closest_hub = hubs_proj.loc[closest_hub_idx]

        # Calculate the distance (now in meters, or the projected unit)
        dist = c_deliver.distance(closest_hub.geometry)

        # Create the connection line
        line = LineString([closest_hub.geometry, c_deliver])

        # Store connection info
        # We use original indices from the input GDFs for clarity
        connections.append({
            'HubIndex': hubs_gdf.index[closest_hub_idx],
            'DeliveryIndex': delivery_points_gdf.index[i],
            'Distance_m': dist,  # Explicitly state units
            'geometry': line
        })

    # Convert the list of connections into a GeoDataFrame
    # The CRS of this new GDF is the projected CRS
    gdf_conn = gpd.GeoDataFrame(connections, geometry='geometry', crs=hubs_proj.crs)

    # --- Save Output ---
    # It's best practice to save GeoJSON in WGS84 (EPSG:4326)
    print(f"Re-projecting final network back to EPSG:4326 for saving.")
    gdf_conn_4326 = gdf_conn.to_crs(epsg=4326)

    # Ensure the output directory exists
    os.makedirs(os.path.dirname(output_file), exist_ok=True)

    # Save the connections to GeoJSON
    gdf_conn_4326.to_file(output_file, driver='GeoJSON')
    print(f"Connection network saved to {output_file}")

    # Return the GeoDataFrame with meter-based distances (in its projected CRS)
    # for potential further use (e.g., saving to Shapefile)
    return gdf_conn


def main():
    """
    Main execution function for the script.
    """
    print("Script started.")

    # --- Configuration ---
    CITY_NAME = "Beijing"
    BASE_CRS_EPSG = 4326  # WGS84 (lat/lon)

    # --- File Paths ---
    # Use os.path.join for cross-platform compatibility
    DATA_DIR = os.path.join("Data", CITY_NAME)
    NETWORK_DIR = os.path.join(DATA_DIR, "Network")

    # Input files
    HUB_CSV = os.path.join(DATA_DIR, "Hub_coordinates.csv")
    DN_CSV = os.path.join(DATA_DIR, "DN_coordinates.csv")

    # Output files
    HUB_GEOJSON = os.path.join(NETWORK_DIR, "Hub.geojson")
    DN_GEOJSON = os.path.join(NETWORK_DIR, "DN.geojson")
    NETWORK_GEOJSON = os.path.join(NETWORK_DIR, "Network.geojson")
    NETWORK_SHP = os.path.join(NETWORK_DIR, "Network.shp")

    # Ensure the main output directory exists
    os.makedirs(NETWORK_DIR, exist_ok=True)
    print(f"Output directory set to: {NETWORK_DIR}")

    # --- Step 1: Convert Hubs CSV to GeoDataFrame ---
    hubs_gdf = convert_csv_to_gdf(
        csv_file=HUB_CSV,
        output_file=HUB_GEOJSON,
        x_col='log',
        y_col='lat',
        crs_epsg=BASE_CRS_EPSG
    )
    if hubs_gdf is None:
        print("Failed to process Hubs. Exiting.")
        return

    # --- Step 2: Convert Delivery Nodes CSV to GeoDataFrame ---
    dn_gdf = convert_csv_to_gdf(
        csv_file=DN_CSV,
        output_file=DN_GEOJSON,
        x_col='log',
        y_col='lat',
        crs_epsg=BASE_CRS_EPSG
    )
    if dn_gdf is None:
        print("Failed to process Delivery Nodes. Exiting.")
        return

    # --- Step 3: Generate Network Connections ---
    # This function now handles projection and distance calculation
    network_gdf = generate_delivery_connections(
        hubs_gdf,
        dn_gdf,
        NETWORK_GEOJSON
    )

    # --- Step 4: Save Network to Shapefile ---
    # The returned network_gdf is in a projected CRS (good for Shapefiles)
    if network_gdf is not None:
        try:
            network_gdf.to_file(NETWORK_SHP, driver="ESRI Shapefile")
            print(f"Network successfully saved to {NETWORK_SHP}")
        except Exception as e:
            print(f"Error saving Shapefile: {e}")
            print("Note: Shapefile driver may have restrictions (e.g., column name length).")

    print("Script finished.")


if __name__ == "__main__":
    main()