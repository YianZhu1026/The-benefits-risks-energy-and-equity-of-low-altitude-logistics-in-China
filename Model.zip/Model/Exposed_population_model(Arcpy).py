# -*- coding: utf-8 -*-
"""
ArcGIS (arcpy) Script for Temporal Population Aggregation

This script processes 24 hourly population CSV files and aggregates them
into a single master grid (mesh) Shapefile.

It iterates from hour 00 to 23. In each step, it:
1. Converts the hourly population CSV (with lat/lon) to a point Shapefile.
2. Performs a spatial join against a grid Shapefile.
3. Uses a "one-to-one" join with the "CONTAINS" match option to
   sum all point 'value' fields that fall within each grid polygon.
4. The script iteratively passes the output grid from one hour as the
   input grid for the next, accumulating the population data.
5. The final output is a single Shapefile (e.g., 'mesh_harbin.shp')
   containing 24 fields: 'value_00', 'value_01', ..., 'value_23'.
"""

import arcpy
import os
import sys

# --- CONFIGURATION ---
# PLEASE EDIT ALL PATHS AND NAMES IN THIS SECTION
# ---------------------

# 1. Set the ArcGIS workspace (the main directory for your data)
# ！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！
WORKSPACE_DIR = "F:/ResearchData/05-Paper/05_UAV4NC_2025/Code/Data/City/Harbin"

# --- Input Folders & Files ---

# 2. Directory containing the 24 hourly population CSVs
POPULATION_CSV_DIR = "Population"

# 3. The base grid (mesh) to join data to (used for hour 0)
# ！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！
BASE_GRID_SHP = os.path.join("mesh", "mesh_heb1.shp")

# 4. Naming pattern for the input CSV files.
#    {time} will be replaced with '00', '01', etc.
# ！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！
CSV_FILENAME_PATTERN = "哈尔滨市_20240530{time}.csv"

# --- Output Folders & Files ---

# 5. Directory to store intermediate point Shapefiles (e.g., '00.shp')
TEMP_POINTS_DIR = "Pop_point"

# 6. Directory to store intermediate grid Shapefiles (e.g., 'mesh_01.shp')
TEMP_MESH_DIR = "mesh"

# 7. The final, master output Shapefile
# ！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！
FINAL_OUTPUT_SHP = os.path.join("mesh", "mesh_harbin.shp")

# --- CSV Field Names (Case-sensitive) ---
X_FIELD = "wgs84_LNG"  # Longitude field in CSV
Y_FIELD = "wgs84_LAT"  # Latitude field in CSV
VALUE_FIELD = "value"  # Population/data field in CSV to be summed

# --- CRS ---
# EPSG:4326 = WGS84 (lat/lon)
INPUT_CRS = arcpy.SpatialReference(4326)

# --- Field Naming in Output ---
# e.g., "value_00", "value_01"
OUTPUT_FIELD_PREFIX = "value_"
# e.g., "Population at 00:00"
OUTPUT_FIELD_ALIAS_PATTERN = "Population at {time}:00"

# --- Optional Cleanup ---
# Set to True to delete intermediate point files (e.g., '00.shp')
CLEANUP_TEMP_POINTS = True


# ---------------------
# END OF CONFIGURATION
# ---------------------


def main():
    """
    Main function to execute the geoprocessing workflow.
    """
    try:
        # --- 1. Environment Setup ---
        arcpy.env.workspace = WORKSPACE_DIR
        arcpy.env.overwriteOutput = True
        print(f"Workspace set to: {arcpy.env.workspace}")

        # Create output directories if they don't exist
        temp_points_full_path = os.path.join(WORKSPACE_DIR, TEMP_POINTS_DIR)
        temp_mesh_full_path = os.path.join(WORKSPACE_DIR, TEMP_MESH_DIR)

        if not os.path.exists(temp_points_full_path):
            os.makedirs(temp_points_full_path)
            print(f"Created directory: {temp_points_full_path}")

        if not os.path.exists(temp_mesh_full_path):
            os.makedirs(temp_mesh_full_path)
            print(f"Created directory: {temp_mesh_full_path}")

        # --- 2. Main Loop ---
        # This loop processes each hour from 0 to 23
        for hour in range(24):
            time_str = str(hour).zfill(2)  # '00', '01', ..., '23'
            print(f"\n--- Processing hour: {time_str}:00 ---")

            # --- Define File Paths for this hour ---
            input_csv = os.path.join(POPULATION_CSV_DIR, CSV_FILENAME_PATTERN.format(time=time_str))
            output_points = os.path.join(TEMP_POINTS_DIR, f"{time_str}.shp")

            # Define input and output grids for the spatial join
            if hour == 0:
                # First iteration: use the base grid
                input_grid = BASE_GRID_SHP
            else:
                # Subsequent iterations: use the output from the *previous* hour
                input_grid = os.path.join(TEMP_MESH_DIR, f"mesh_{time_str}.shp")

            if hour == 23:
                # Final iteration: save to the final output path
                output_joined_grid = FINAL_OUTPUT_SHP
            else:
                # Intermediate iteration: save to a temporary file for the next loop
                next_time_str = str(hour + 1).zfill(2)
                output_joined_grid = os.path.join(TEMP_MESH_DIR, f"mesh_{next_time_str}.shp")

            # --- 3. Convert CSV to Point Shapefile ---
            print(f"  Converting {input_csv} to {output_points}...")
            arcpy.management.XYTableToPoint(
                in_table=input_csv,
                out_feature_class=output_points,
                x_field=X_FIELD,
                y_field=Y_FIELD,
                coordinate_system=INPUT_CRS
            )

            # --- 4. Create Field Mappings to Accumulate Data ---
            # This is the core logic: we copy all existing 'value_XX' fields
            # from the input grid and add a new one for the current hour.

            # Create a new, empty FieldMappings object
            field_mappings = arcpy.FieldMappings()

            # (A) Add fields from *previous* hours (if this isn't the first hour)
            if hour > 0:
                for existing_field in arcpy.ListFields(input_grid):
                    if existing_field.name.startswith(OUTPUT_FIELD_PREFIX):
                        # Create a new FieldMap for the existing field
                        field_map = arcpy.FieldMap()
                        # Add the field from the input grid
                        field_map.addInputField(input_grid, existing_field.name)
                        # Add this map to the main mappings object
                        field_mappings.addFieldMap(field_map)

            # (B) Add the field for the *current* hour's data
            field_map_current = arcpy.FieldMap()
            field_map_current.addInputField(output_points, VALUE_FIELD)

            # Set the merge rule to 'SUM'
            # This sums all point 'value' fields within one grid polygon
            field_map_current.mergeRule = "SUM"

            # Rename the output field (e.g., 'value' -> 'value_00')
            output_field = field_map_current.outputField
            output_field.name = f"{OUTPUT_FIELD_PREFIX}{time_str}"
            output_field.aliasName = OUTPUT_FIELD_ALIAS_PATTERN.format(time=time_str)
            field_map_current.outputField = output_field

            # Add the new field map for the current hour
            field_mappings.addFieldMap(field_map_current)

            # --- 5. Perform Spatial Join ---
            print(f"  Joining {output_points} into {os.path.basename(output_joined_grid)}...")
            arcpy.analysis.SpatialJoin(
                target_features=input_grid,
                join_features=output_points,
                out_feature_class=output_joined_grid,
                join_operation="JOIN_ONE_TO_ONE",
                join_type="KEEP_ALL",
                match_option="CONTAINS",
                field_mapping=field_mappings
            )

            print(f"  Successfully created {os.path.basename(output_joined_grid)}")

            # --- 6. Cleanup (Optional) ---
            if CLEANUP_TEMP_POINTS:
                try:
                    arcpy.management.Delete(output_points)
                    print(f"  Deleted intermediate file: {output_points}")
                except Exception as e:
                    print(f"Warning: Could not delete intermediate file {output_points}. {e}")

        print(f"\nProcessing complete!")
        print(f"Final aggregated output saved to: {FINAL_OUTPUT_SHP}")

    except arcpy.ExecuteError:
        # Catch arcpy-specific errors and print them
        print("ArcPy Error:")
        print(arcpy.GetMessages(2))
    except Exception as e:
        # Catch all other Python errors
        print(f"An unexpected error occurred: {e}")
        tb = sys.exc_info()[2]
        print(f"Error on line {tb.tb_lineno}")
    finally:
        # Check out any extensions if they were used (e.g., arcpy.CheckOutExtension("Spatial"))
        pass


# --- Run the main function ---
if __name__ == "__main__":
    main()